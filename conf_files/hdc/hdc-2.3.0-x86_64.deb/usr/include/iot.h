/**
 * @file
 * @brief Header file for using the Internet of Things library
 *
 * @copyright Copyright (C) 2016-2017 Wind River Systems, Inc. All Rights Reserved.
 *
 * @license The right to copy, distribute or otherwise make use of this software
 * may be licensed only pursuant to the terms of an applicable Wind River
 * license agreement.  No license to Wind River intellectual property rights is
 * granted herein.  All rights not licensed by Wind River are reserved by Wind
 * River.
 */
#ifndef IOT_H
#define IOT_H

#ifdef _MSC_VER
#	pragma warning( push, 1 )
#endif /* ifdef _MSC_VER */
#include <stddef.h> /* for size_t */
#ifdef _MSC_VER
#	pragma warning( pop )
#endif /* ifdef _MSC_VER */

#include <stdint.h> /* for uint8_t, uint16_t, uint32_t, etc. */

#ifdef __cplusplus
extern "C" {
#endif /* ifdef __cplusplus */

/* Compiler defines */
#ifndef __GNUC__
/**
 * @brief Removes the GCC specific __attribute__ flag from non-GCC compilers
 */
#	define __attribute__(x)
#endif /* ifndef __GNUC__ */

/**
 * @def IOT_SECTION
 * @brief Macro to add compiler specifications for hints where to store library
 * functions in memory
 */
#ifdef ARDUINO
#	define IOT_SECTION __attribute__((section(".irom0.text")))
#else
#	define IOT_SECTION
#endif /* ifdef ARDUINO */

/**
 * @def IOT_API
 * @brief Macro to add compiler specifications for external/internal functions
 */
#ifdef IOT_STATIC
#	define IOT_API
#else /* ifdef IOT_STATIC */
#	if defined _WIN32 || defined __CYGWIN__
#		if iot_EXPORTS
#			ifdef __GNUC__
#				define IOT_API __attribute__((dllexport))
#			else
#				define IOT_API __declspec(dllexport)
#			endif
#		else /* if iot_EXPORTS */
#			ifdef __GNUC__
#				define IOT_API __attribute__((dllimport))
#			else
#				define IOT_API __declspec(dllimport)
#			endif
#		endif /* if iot_EXPORTS */
#	else /* if defined _WIN32 || defined __CYGWIN__ */
#		if __GNUC__ >= 4
#			define IOT_API __attribute__((visibility("default")))
#		else
#			define IOT_API
#		endif
#	endif /* if defined _WIN32 || defined __CYGWIN__ */
#endif /* ifdef IOT_STATIC */

/* types */
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-macros"
#endif /* ifdef __clang__ */

/* log support  */
/**
 * @def IOT_FUNC
 * @brief Contains the name of the current function
 */
#ifdef __GNUC__
#	define IOT_FUNC __func__
#else
#	define IOT_FUNC __FUNCTION__
#endif /* __GNUC__ */

/**
 * @def IOT_LOG
 * @brief Macro to quickly write a log message
 */
#ifdef IOT_OS_MICRO
#define IOT_LOG( handle, level, fmt, ... ) while ( 0 )
#else
#define IOT_LOG( handle, level, fmt, ... ) \
	(void) iot_log( handle, level, IOT_FUNC, __FILE__, __LINE__, fmt, __VA_ARGS__ )
#endif /* IOT_OS_MICRO */

/** @brief False */
#define IOT_FALSE                                (iot_bool_t)(0 == 1)
/** @brief True */
#define IOT_TRUE                                 (iot_bool_t)(1 == 1)

#ifdef __clang__
#pragma clang diagnostic pop
#endif /* ifdef __clang__ */

/**
 * @brief Possible location sources
 */
enum iot_location_source {
	/**< @brief Unknown location source */
	IOT_LOCATION_SOURCE_UNKNOWN = 0,
	/**< @brief Fixed location */
	IOT_LOCATION_SOURCE_FIXED,
	/**< @brief Global positioning system source */
	IOT_LOCATION_SOURCE_GPS,
	/**< @brief Wireless position system source */
	IOT_LOCATION_SOURCE_WIFI
};

/**
 * @defgroup iot_types List of basic IoT types
 * @{
 */
/** @brief IoT boolean (true or false) */
typedef int                                      iot_bool_t;
/** @brief IoT 32-bit floating-point */
typedef float                                    iot_float32_t;
/** @brief IoT 64-bit floating-point */
typedef double                                   iot_float64_t;
/** @brief IoT 8-bit signed integer */
typedef int8_t                                   iot_int8_t;
/** @brief IoT 16-bit signed integer */
typedef int16_t                                  iot_int16_t;
/** @brief IoT 32-bit signed integer */
typedef int32_t                                  iot_int32_t;
/** @brief IoT 64-bit signed integer */
typedef int64_t                                  iot_int64_t;
/** @brief IoT 8-bit unsigned integer */
typedef uint8_t                                  iot_uint8_t;
/** @brief IoT 16-bit unsigned integer */
typedef uint16_t                                 iot_uint16_t;
/** @brief IoT 32-bit unsigned integer */
typedef uint32_t                                 iot_uint32_t;
/** @brief IoT 64-bit unsigned integer */
typedef uint64_t                                 iot_uint64_t;
/** @brief IoT time interval in milliseconds */
typedef uint32_t                                 iot_millisecond_t;
/** @brief IoT time stamp in milliseconds */
typedef uint64_t                                 iot_timestamp_t;

/** @brief Type representing a connection to between the client and agent */
typedef struct iot                               iot_t;
/** @brief Type representing an action that can be triggered from the cloud */
typedef struct iot_action                        iot_action_t;
/** @brief Type representing an action request from the cloud */
typedef struct iot_action_request                iot_action_request_t;
/** @brief Type representing a location sample */
typedef struct iot_location                      iot_location_t;
/** @brief Type representing a location source type within the system */
typedef enum iot_location_source                 iot_location_source_t;
/** @brief Type representing a telemetry data */
typedef struct iot_telemetry                     iot_telemetry_t;
/** @brief Type representing communication between client and agent */
typedef struct iot_transaction                   iot_transaction_t;
/** @brief Type containing verison information for the library */
typedef iot_uint32_t                             iot_version_t;

/**
 * @}
 */


/** @brief indicates data type */
typedef enum iot_type
{
	/** @brief Undefined type */
	IOT_TYPE_NULL = 0,
	/** @brief Boolean type */
	IOT_TYPE_BOOL,
	/** @brief 32-bit floating point */
	IOT_TYPE_FLOAT32,
	/** @brief 64-bit floating point */
	IOT_TYPE_FLOAT64,
	/** @brief 8-bit signed integer */
	IOT_TYPE_INT8,
	/** @brief 16-bit signed integer */
	IOT_TYPE_INT16,
	/** @brief 32-bit signed integer */
	IOT_TYPE_INT32,
	/** @brief 64-bit signed integer */
	IOT_TYPE_INT64,
	/** @brief location object */
	IOT_TYPE_LOCATION,
	/** @brief Raw binary data */
	IOT_TYPE_RAW,
	/** @brief UTF-8 String data */
	IOT_TYPE_STRING,
	/** @brief 8-bit unsigned integer */
	IOT_TYPE_UINT8,
	/** @brief 16-bit unsigned integer */
	IOT_TYPE_UINT16,
	/** @brief 32-bit unsigned integer */
	IOT_TYPE_UINT32,
	/** @brief 64-bit unsigned integer */
	IOT_TYPE_UINT64
} iot_type_t;

/**
 * @brief Possible return code values
 */
typedef enum iot_status
{
	/** @brief Success */
	IOT_STATUS_SUCCESS = 0,
	/** @brief Action successfully invoked (fire & forget) */
	IOT_STATUS_INVOKED,
	/** @brief Invalid parameter passed */
	IOT_STATUS_BAD_PARAMETER,
	/** @brief Bad request received */
	IOT_STATUS_BAD_REQUEST,
	/** @brief Error executing the requested action */
	IOT_STATUS_EXECUTION_ERROR,
	/** @brief Already exists */
	IOT_STATUS_EXISTS,
	/** @brief File open failed */
	IOT_STATUS_FILE_OPEN_FAILED,
	/** @brief Full storage */
	IOT_STATUS_FULL,
	/** @brief Input/output error */
	IOT_STATUS_IO_ERROR,
	/** @brief No memory */
	IOT_STATUS_NO_MEMORY,
	/** @brief Not executable */
	IOT_STATUS_NOT_EXECUTABLE,
	/** @brief Not found */
	IOT_STATUS_NOT_FOUND,
	/** @brief Not Initialized */
	IOT_STATUS_NOT_INITIALIZED,
	/** @brief Parameter out of range */
	IOT_STATUS_OUT_OF_RANGE,
	/** @brief Failed to parse a message */
	IOT_STATUS_PARSE_ERROR,
	/** @brief Timed out */
	IOT_STATUS_TIMED_OUT,
	/** @brief Try again */
	IOT_STATUS_TRY_AGAIN,
	/** @brief Not supported in this version of the api */
	IOT_STATUS_NOT_SUPPORTED,

	/**
	 * @brief General failure
	 * @note This must be the last state
	 */
	IOT_STATUS_FAILURE
} iot_status_t;

/**
 * @defgroup iot_parameter_flags IoT parameter flags
 *
 * The following bits corrospond to the following meanings:
 * - 0001 (1): IN parameter only, not required
 * - 0010 (2): (computed as neither defined)
 * - 0011 (3): IN parameter only, required
 * - 0100 (4): OUT parameter only, not required
 * - 0101 (5): IN/OUT parameter only, not required
 * - 0110 (6): (computed as OUT not required; IN not defined)
 * - 0111 (7): IN parameter required, OUT parameter not required
 * - 1000 (8): (computed as neither defined)
 * - 1001 (9): (computed as IN parameter only, not required; OUT not defined)
 * - 1010 (A): (computed as neither defined)
 * - 1011 (B): (computed as IN required; OUT not defined)
 * - 1100 (C): OUT parameter required
 * - 1101 (D): OUT parameter required, IN parameter not required
 * - 1110 (E): (computed as OUT required; IN not defined)
 * - 1111 (F): IN/OUT parameter, both required
 *
 * @{
 */
/** @brief Parameter type */
typedef iot_uint8_t iot_parameter_type_t;
/** @brief IN parameter */
#define IOT_PARAMETER_IN                         0x1
/** @brief IN/OUT parameter */
#define IOT_PARAMETER_IN_OUT                     0x5
/** @brief IN/OUT required parameter */
#define IOT_PARAMETER_IN_OUT_REQUIRED            0xF
/** @brief IN required parameter */
#define IOT_PARAMETER_IN_REQUIRED                0x3
/** @brief OUT parameter */
#define IOT_PARAMETER_OUT                        0x4
/** @brief OUT required parameter */
#define IOT_PARAMETER_OUT_REQUIRED               0xC
/**
 * @}
 */

/**
 * @brief log message severity levels
 */
typedef enum iot_log_level
{
	/** @brief Fatal (unrecoverable error) */
	IOT_LOG_FATAL = 0,
	/** @brief Alert (most likely unrecoverable error) */
	IOT_LOG_ALERT,
	/** @brief Critical (recoverable, but not good) */
	IOT_LOG_CRITICAL,
	/** @brief Error (recoverable error) */
	IOT_LOG_ERROR,
	/** @brief Warning (something needs attention) */
	IOT_LOG_WARNING,
	/** @brief Notice (something could be correct or incorrect) */
	IOT_LOG_NOTICE,
	/** @brief Information (helpful information) */
	IOT_LOG_INFO,
	/** @brief Debug (useful for debugging purposes) */
	IOT_LOG_DEBUG,
	/** @brief Tracing execution (tracing the execution path) */
	IOT_LOG_TRACE,
	/**
	 * @brief None (useful for compatible purposes)
	 * @note This must be the last state
	 * */
	IOT_LOG_ALL
} iot_log_level_t;

/** @brief Contains information about where a log message was generated */
typedef struct iot_log_source
{
	/** @brief Name of source file that generated log message */
	const char *file_name;
	/** @brief Name of function that generated log message */
	const char *function_name;
	/** @brief Line number that generated log message */
	unsigned int line_number;
} iot_log_source_t;

/**
 * @defgroup state Possible states of the system
 * @{
 */
/** @brief Not connected to cloud */
#define IOT_STATE_NOT_CONNECTED                  0
/** @brief Connected to cloud */
#define IOT_STATE_CONNECTED                      1

/**
 * @brief Last state (not a true state
 * @note This must be the last state (i.e. highest number)
 */
#define IOT_STATE_LAST                          (IOT_STATE_CONNECTED)
/** @brief State of client */
typedef int iot_state_t;
/**
 * @}
 */

/**
 * @brief Type for a callback function called when an internal action is
 * requested
 *
 * @param[in]      request                       information about the request
 *                                               that invoked the callback
 * @param[in]      user_data                     pointer to user specific data
 *
 * @return a return code indicating if action was handled
 */
typedef iot_status_t (iot_action_callback_t)(
	iot_action_request_t *request,
	void *user_data );

/**
 * @brief Type for a callback function called when log information is produced
 *
 * @param[in]      log_level                     log level of the message
 * @param[in]      log_source                    source of log message
 * @param[in]      message                       log message
 * @param[in]      user_data                     pointer to user specific data
 */
typedef void (iot_log_callback_t)(
	iot_log_level_t log_level,
	iot_log_source_t *log_source,
	const char *message,
	void *user_data );

/* common */
/**
 * @brief Connects to an agent
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      max_time_out                  maximum time to wait in
 *                                               milliseconds for connection
 *
 * @note Setting the parameter @p max_time_out to a value of @p 0, will cause
 *       the function to wait indefinitely for a connection
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    on success
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               connection
 *
 * @see iot_disconnect
 */
IOT_API IOT_SECTION iot_status_t iot_connect(
	iot_t *handle,
	iot_millisecond_t max_time_out );

/**
 * @brief Disconnects from an agent
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      max_time_out                  maximum time to wait in
 *                                               milliseconds for disconnection
 *
 * @note Setting the parameter @p max_time_out to a value of @p 0, will cause
 *       the function to wait indefinitely for disconnection
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    on success
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               disconnection
 *
 * @see iot_connect
 */
IOT_API IOT_SECTION iot_status_t iot_disconnect(
	iot_t *handle,
	iot_millisecond_t max_time_out );

/**
 * @brief Translates an error number into an error message
 *
 * @param[in]      code                          id of the error to return the
 *                                               message for
 *
 * @return the string corresponding to the error identifier specified
 */
IOT_API IOT_SECTION const char *iot_error(
	iot_status_t code );

/**
 * @brief Initialize the library
 *
 * @param[in]      id                            unique token identifying device
 * @param[in]      app_path                      path of the executable running
 *                                               the api (optional)
 * @param[in]      flags                         initialization flags
 *
 * @return A reference handle to the library
 *
 * @see iot_terminate
 */
IOT_API IOT_SECTION iot_t *iot_initialize(
	const char *id,
	const char *app_path,
	unsigned int flags );

/**
 * @brief Internal function to log data
 *
 * @param[in]      handle                        library handle
 * @param[in]      log_level                     log level of the message
 * @param[in]      function_name                 name of function that generated
 *                                               the log message
 * @param[in]      file_name                     name of source file that
 *                                               generated the log message
 * @param[in]      line_number                   line number within the source
 *                                               code that generated the message
 * @param[in]      log_msg_fmt                   message to log in printf format
 * @param[in]      ...                           replacement values as specified
 *                                               by the format
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_log_callback_set
 * @see IOT_LOG
 */
IOT_API IOT_SECTION iot_status_t iot_log(
	iot_t *handle,
	iot_log_level_t log_level,
	const char *function_name,
	const char *file_name,
	unsigned int line_number,
	const char *log_msg_fmt, ... )
	__attribute__((format(printf,6,7)));

/**
 * @brief Sets a callback to be called when a log message is available to be
 *        published
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      log_callback                  callback to be called on a log
 *                                               message
 * @param[in]      user_data                     user data pointer to pass
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_log
 * @see IOT_LOG
 */
IOT_API IOT_SECTION iot_status_t iot_log_callback_set(
	iot_t *handle,
	iot_log_callback_t *log_callback,
	void *user_data );

/**
 * @brief Sets a log level for the service
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      level                         log level filter for the service
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_log
 * @see IOT_LOG
 */
IOT_API IOT_SECTION iot_status_t iot_log_level_set(
	iot_t *handle,
	iot_log_level_t level );

/**
 * @brief Destroys memory associated with the library
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      max_time_out                  maximum time to wait in
 *                                               milliseconds for termination
 *
 * @note Setting the parameter @p max_time_out to a value of @p 0, will cause
 *       this function to wait forever for a termination signal.
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    on success
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               termination
 *
 * @see iot_initialize
 */
IOT_API IOT_SECTION iot_status_t iot_terminate(
	iot_t *handle,
	iot_millisecond_t max_time_out );

/* actions */
/**
 * @brief Allocates memory for a new action that can be registered
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      name                          name of the action
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    pointer was successfully set
 *
 * @see iot_action_free
 */
IOT_API IOT_SECTION iot_action_t *iot_action_allocate(
	iot_t *handle,
	const char *name );

/**
 * @brief Sets an attribute value for a action object
 *
 * @param[in,out]  action                        action object to set
 * @param[in]      name                          attibute name
 * @param[in]      type                          type of attribute data
 * @param[in]      ...                           value of attribute data in the
 *                                               type specified
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_FULL                       maximum number of attributes
 *                                               reached
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_action_attribute_set_raw
 */
IOT_API IOT_SECTION iot_status_t iot_action_attribute_set(
	iot_action_t *action,
	const char *name,
	iot_type_t type,
	... );

/**
 * @brief Sets a raw attribute value for a action object
 *
 * @param[in,out]  action                        action object to set
 * @param[in]      name                          attibute name
 * @param[in]      length                        length of attribute data
 * @param[in]      ptr                           pointer to attribute data
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_FULL                       maximum number of attributes
 *                                               reached
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_action_attribute_set
 */
IOT_API IOT_SECTION iot_status_t iot_action_attribute_set_raw(
	iot_action_t *action,
	const char *name,
	size_t length,
	const void *ptr );

/**
 * @brief Deregisters an action from an agent
 *
 * @param[in,out]  action                        action to deregister
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait for
 *                                               the deregistration to complete
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
`* @retval IOT_STATUS_NOT_INITIALIZED            action was not initialized
 * @retval IOT_STATUS_SUCCESS                    pointer was successfully set
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               deregistration
 *
 * @see iot_action_register_callback
 * @see iot_action_register_command
 */
IOT_API IOT_SECTION iot_status_t iot_action_deregister(
	iot_action_t *action,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out );

/**
 * @brief Frees memory for an allocated action
 *
 * @param[in,out]  action                        action to deregister and free
 * @param[in]      max_time_out                  maximum time to wait for
 *                                               the deregistration to complete
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    pointer was successfully set
 *
 * @see iot_action_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_action_free(
	iot_action_t *action,
	iot_millisecond_t max_time_out );

/**
 * @brief Adds a parameter to an action
 *
 * @param[in,out]  action                        action to add the parameter to
 * @param[in]      name                          name of the parameter
 * @param[in]      param_type                    type of the parameter
 *                                               (in and/or out)
 * @param[in]      data_type                     data type of the parameter
 * @param[in]      max_time_out                  maximum time to wait in
 *                                               milliseconds for parameter
 *                                               addition
 *
 * @note Setting the parameter @p max_time_out to a value of @p 0, will cause
 *       the function to wait forever for parameter addition
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                parameter name already exists
 * @retval IOT_STATUS_FULL                       maximum number of parameters
 *                                               reached
 * @retval IOT_STATUS_SUCCESS                    on success
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               parameter addition
 */
IOT_API IOT_SECTION iot_status_t iot_action_parameter_add(
	iot_action_t *action,
	const char *name,
	iot_parameter_type_t param_type,
	iot_type_t data_type,
	iot_millisecond_t max_time_out );

/**
 * @brief Returns the value of a parameter
 *
 * @param[in]      request                       action request
 * @param[in]      name                          parameter name
 * @param[in]      convert                       convert to type, if possible
 * @param[in]      type                          type of data to return
 * @param[in,out]  ...                           pointer to a variable of the
 *                                               type specified
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type doesn't match parameter
 *                                               (and not convertible, if set)
 * @retval IOT_STATUS_NOT_FOUND                  parameter name not found
 * @retval IOT_STATUS_NOT_INITIALIZED            no value exists for parameter
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_parameter_get_raw
 * @see iot_parameter_set
 */
IOT_API IOT_SECTION iot_status_t iot_action_parameter_get(
	const iot_action_request_t *request,
	const char *name,
	iot_bool_t convert,
	iot_type_t type,
	... );

/**
 * @brief Returns a raw value of a parameter
 *
 * @param[in]      request                       action request
 * @param[in]      name                          parameter name
 * @param[in]      convert                       convert to raw, if possible
 * @param[out]     length                        amount of raw data
 * @param[in,out]  data                          pointer to the raw data
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type doesn't match parameter
 *                                               (and not convertible, if set)
 * @retval IOT_STATUS_NOT_FOUND                  parameter name not found
 * @retval IOT_STATUS_NOT_INITIALIZED            no value exists for parameter
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_parameter_get
 * @see iot_parameter_set_raw
 */
IOT_API IOT_SECTION iot_status_t iot_action_parameter_get_raw(
	const iot_action_request_t *request,
	const char *name,
	iot_bool_t convert,
	size_t *length,
	const void **data );

/**
 * @brief Sets the value of a parameter
 *
 * @param[in]      request                       action request
 * @param[in]      name                          parameter name
 * @param[in]      type                          type of data
 * @param[in]      ...                           value of the specified type
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type doesn't match parameter
 * @retval IOT_STATUS_FULL                       no space to store new parameter
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_parameter_get
 * @see iot_parameter_set_raw
 */
IOT_API IOT_SECTION iot_status_t iot_action_parameter_set(
	iot_action_request_t *request,
	const char *name,
	iot_type_t type,
	... );

/**
 * @brief Sets the raw value of a parameter
 *
 * @param[in]      request                       action request
 * @param[in]      name                          parameter name
 * @param[out]     length                        amount of raw data
 * @param[in,out]  data                          pointer to the raw data
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type doesn't match parameter
 * @retval IOT_STATUS_FULL                       no space to store new parameter
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_parameter_get_raw
 * @see iot_parameter_set
 */
IOT_API IOT_SECTION iot_status_t iot_action_parameter_set_raw(
	iot_action_request_t *request,
	const char *name,
	size_t length,
	const void *data );

/**
 * @brief Registers an action with a callback
 *
 * @param[in,out]  action                        action to register
 * @param[in]      func                          function pointer to be called
 * @param[in]      user_data                     user data to pass to function
 *                                               (optional)
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait for
 *                                               the registration to complete
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    pointer was successfully set
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               registration
 *
 * @see iot_action_deregister
 * @see iot_action_register_command
 */
IOT_API IOT_SECTION iot_status_t iot_action_register_callback(
	iot_action_t *action,
	iot_action_callback_t *func,
	void *user_data,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out );

/**
 * @brief Registers an action with a system command
 *
 * @param[in,out]  action                        action to register
 * @param[in]      command                       command to be called
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait for
 *                                               the registration to complete
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    pointer was successfully set
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               registration
 *
 * @see iot_action_deregister
 * @see iot_action_register_command
 */
IOT_API IOT_SECTION iot_status_t iot_action_register_command(
	iot_action_t *action,
	const char *command,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out );

#ifndef iot_EXPORTS
#ifndef __clang__
/**
 * @brief Sets an attribute for a action object
 *
 * @param[in,out]  action                        object to set attribute for
 * @param[in]      name                          attribute name
 * @param[in]      type                          attribute type
 * @param[in]      data                          attribute value
 */
#	define iot_action_attribute_set( action, name, type, data ) \
		iot_action_attribute_set( action, name, type, data )

/**
 * @brief Retrieve a parameter value for an action being handled
 * @param[in]      request                       action request
 * @param[in]      name                          parameter name
 * @param[in]      convert                       convert to type, if possible
 * @param[in]      type                          data type
 * @param[out]     data_ptr                      pointer to store value
 */
#	define iot_action_parameter_get( request, name, convert, type, data_ptr ) \
		iot_action_parameter_get( request, name, convert, type, data_ptr )

/**
 * @brief Sets a parameter value for an action being handled
 * @param[in,out]  request                       action request
 * @param[in]      name                          parameter name
 * @param[in]      type                          data type
 * @param[in]      data                          value to set
 */
#	define iot_action_parameter_set( request, name, type, data ) \
		iot_action_parameter_set( request, name, type, data )
#endif /* ifndef __clang__ */
#endif /* ifndef iot_EXPORTS */

/* location */
/**
 * @brief Sets the accuracy for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      accuracy                      accuracy for the location
 *                                               sample (in metres)
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_accuracy_set(
	iot_location_t *sample, iot_float64_t accuracy );

/**
 * @brief Allocates memory for a new location sample
 *
 * @param[in]      latitude                      latitude for the new sample
 *                                               (in degrees)
 *                                               (range: -90.0 to 90.0)
 * @param[in]      longitude                     longitude for the new sample
 *                                               (in degrees)
 *                                               (range: -180.0 to 180.0)
 *
 * @return a reference to the new location sample, NULL on failure
 *
 * @see iot_location_free
 */
IOT_API IOT_SECTION iot_location_t* iot_location_allocate(
	iot_float64_t latitude, iot_float64_t longitude );

/**
 * @brief Sets the accuracy of the altitude for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      accuracy                      altitude accuracy for the
 *                                               location sample (in metres)
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 * @see iot_location_altitude_set
 */
IOT_API IOT_SECTION iot_status_t iot_location_altitude_accuracy_set(
	iot_location_t* sample, iot_float64_t accuracy );

/**
 * @brief Sets the altitude for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      altitude                      altitude for the location
 *                                               sample (in metres)
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 * @see iot_location_altitude_accuracy_set
 */
IOT_API IOT_SECTION iot_status_t iot_location_altitude_set(
	iot_location_t* sample, iot_float64_t altitude );

/**
 * @brief Free memory associated with a location sample
 *
 * @param[in]      sample                        sample to free
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_free( iot_location_t* sample );

/**
 * @brief Sets the heading for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      heading                       heading for the location
 *                                               sample (in degrees)
 *                                               (range: 0.0 to 360.0)
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_heading_set(
	iot_location_t* sample, iot_float64_t heading );

/**
 * @brief Sets the latitude and longitude for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      latitude                      latitude for the sample
 * @param[in]      longitude                     longitude for the sample
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_set( iot_location_t *sample,
	iot_float64_t latitude, iot_float64_t longitude );

/**
 * @brief Sets the source for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      source                        source generating the location
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_source_set(
	iot_location_t* sample, iot_location_source_t source );

/**
 * @brief Sets the speed for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      speed                         speed for the location sample
 *                                               in (m/s)
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_speed_set(
	iot_location_t* sample, iot_float64_t speed );

/**
 * @brief Sets the tag for the location sample
 *
 * @param[in,out]  sample                        object to modify
 * @param[in]      tag                           tag for the location sample
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to
 *                                               function
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_location_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_location_tag_set( iot_location_t* sample,
	const char* tag );

/* telemetry */
/**
 * @brief Allocates a new telemetry object
 *
 * @param[in,out]  handle                        library handle
 * @param[in]      name                          telemetry name
 * @param[in]      type                          type of telemetry data
 *
 * @return a new telemetry object on success, NULL on failure
 *
 * @see iot_telemetry_allocate
 */
IOT_API IOT_SECTION iot_telemetry_t *iot_telemetry_allocate(
	iot_t *handle,
	const char *name,
	iot_type_t type );

/**
 * @brief Sets an attribute value for a telemetry object
 *
 * @param[in,out]  telemetry                     telemetry object to set
 * @param[in]      name                          attibute name
 * @param[in]      type                          type of attribute data
 * @param[in]      ...                           value of attribute data in the
 *                                               type specified
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_FULL                       maximum number of attributes
 *                                               reached
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_telemetry_attribute_set_raw
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_attribute_set(
	iot_telemetry_t *telemetry,
	const char *name,
	iot_type_t type,
	... );

/**
 * @brief Sets a raw attribute value for a telemetry object
 *
 * @param[in,out]  telemetry                     telemetry object to set
 * @param[in]      name                          attibute name
 * @param[in]      length                        length of attribute data
 * @param[in]      ptr                           pointer to attribute data
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_FULL                       maximum number of attributes
 *                                               reached
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_telemetry_attribute_set
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_attribute_set_raw(
	iot_telemetry_t *telemetry,
	const char *name,
	size_t length,
	const void *ptr );

/**
 * @brief Deregisters a telemetry object from the cloud
 *
 * @param[in,out]  telemetry                     telemetry object to deregister
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_NOT_INITIALIZED            telemetry was not initialized
 * @retval IOT_STATUS_SUCCESS                    on success
 * @retval IOT_STATUS_TIMED_OUT                  timed out while waiting for
 *                                               deregistration
 *
 * @see iot_telemetry_register
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_deregister(
	iot_telemetry_t *telemetry,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out );

/**
 * @brief Frees memory associated with a telemetry object
 *
 * @param[in,out]  telemetry                     telemetry object to free
 * @param[in]      max_time_out                  maximum time to wait
 *
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_telemetry_allocate
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_free(
	iot_telemetry_t *telemetry,
	iot_millisecond_t max_time_out );

/**
 * @brief Registers a telemetry object with the cloud
 *
 * @param[in,out]  telemetry                     telemetry object to register
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait
 *
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_telemetry_deregister
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_register(
	iot_telemetry_t *telemetry,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out );

/**
 * @brief Publish a telemetry sample
 *
 * @param[in,out]  telemetry                     telemetry object sample is for
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait
 * @param[in]      type                          type of data to publish
 * @param[in]      ...                           value of data to publish in the
 *                                               type specified
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type does not match registered
 *                                               type
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_NO_MEMORY                  no memory to store telemetry
 *                                               sample
 * @retval IOT_STATUS_NOT_INITIALIZED            telemetry object is not
 *                                               initialized
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 * @see iot_telemetry_publish_raw
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_publish(
	iot_telemetry_t *telemetry,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out,
	iot_type_t type,
	... );

/**
 * @brief Publish a raw telemetry sample
 *
 * @param[in,out]  telemetry                     telemetry object sample is for
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait
 * @param[in]      length                        length of data to publish
 * @param[in]      ptr                           pointer to data to publish
 *
 * @retval IOT_STATUS_BAD_PARAMETER              invalid parameter passed to the
 *                                               function
 * @retval IOT_STATUS_BAD_REQUEST                type does not match registered
 *                                               type
 * @retval IOT_STATUS_FAILURE                    on failure
 * @retval IOT_STATUS_NO_MEMORY                  no memory to store telemetry
 *                                               sample
 * @retval IOT_STATUS_NOT_INITIALIZED            telemetry object is not
 *                                               initialized
 * @retval IOT_STATUS_SUCCESS                    on success
 *
 *
 * @see iot_telemetry_publish
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_publish_raw(
	iot_telemetry_t *telemetry,
	iot_transaction_t *txn,
	iot_millisecond_t max_time_out,
	size_t length,
	const void *ptr );

#ifndef iot_EXPORTS
#ifndef __clang__
/**
 * @brief Sets an attribute for a telemetry object
 *
 * @param[in,out]  telemetry                     object to set attribute for
 * @param[in]      name                          attribute name
 * @param[in]      type                          attribute type
 * @param[in]      data                          attribute value
 */
#	define iot_telemetry_attribute_set( telemetry, name, type, data ) \
		iot_telemetry_attribute_set( telemetry, name, type, data )

/**
 * @brief Publishs telemetry towards the cloud
 *
 * @param[in]      telemetry                     object to publish for
 * @param[out]     txn                           transaction status (optional)
 * @param[in]      max_time_out                  maximum time to wait for
 *                                               telemetry to be published
 * @param[in]      type                          type of data to publish
 * @param[in]      data                          value of data to publish
 */
#	define iot_telemetry_publish( telemetry, txn, max_time_out, type, data ) \
		iot_telemetry_publish( telemetry, txn, max_time_out, type, data )
#endif /* ifndef __clang__ */
#endif /* ifndef iot_EXPORTS */

/**
 * @brief Explicitly sets the time stamp for a piece of telemetry data
 *
 * @param[in,out]  telemetry           object to set time stamp for
 * @param[in]      time_stamp          time stamp for telemetry to set
 *
 * @retval IOT_STATUS_BAD_PARAMETER    invalid parameter passed to function
 * @retval IOT_STATUS_FAILURE          on failure
 * @retval IOT_STATUS_SUCCESS          on success
 *
 * @see iot_telemetry_publish
 * @see iot_telemetry_publish_raw
 * @see iot_timestamp_now
 */
IOT_API IOT_SECTION iot_status_t iot_telemetry_timestamp_set(
	iot_telemetry_t *telemetry,
	iot_timestamp_t time_stamp );

/* time */
/**
 * @brief Initializes a time stamp with the current time
 *
 * @retval 0u                          on failure, or not supported on
 *                                     operating system
 * @retval >0u                         current timestamp in milliseconds
 *
 * @see iot_telemetry_timestamp_set
 */
IOT_API IOT_SECTION iot_timestamp_t iot_timestamp_now( void );

/* version */
/**
 * @brief Returns the version of the library
 * @return Version of the library
 * @see iot_version_major
 * @see iot_version_minor
 * @see iot_version_patch
 * @see iot_version_tweak
 * @see iot_version_str
 */
IOT_API IOT_SECTION iot_version_t iot_version( void );

/**
 * @brief Returns the version of the library as a string
 * @return Version of the library as a string
 * @see iot_version
 */
IOT_API IOT_SECTION const char *iot_version_str( void );

/**
 * @brief Macro used to encode the library version
 *
 * @note This macro can be used for comparing library versions.  For example:
 @code
   if ( iot_version() >= iot_version_encode( 3, 0, 0, 0 ) )
 @endcode
 *
 * @param[in]      major                         major portion of version number
 * @param[in]      minor                         minor portion of version number
 * @param[in]      patch                         patch portion of version number
 * @param[in]      tweak                         tweak portion of version number
 */
#define iot_version_encode( major, minor, patch, tweak ) ( \
	((iot_version_t)major << 24u) | \
	((iot_version_t)minor << 16u) | \
	((iot_version_t)patch << 8u) | tweak)

/**
 * @brief Extracts the major verion portion from a version
 * @param[in]      v                             version to extract from
 * @return the major portion of the version number
 */
#define iot_version_major( v ) ((v >> 24u) & 0xFF)

/**
 * @brief Extracts the minor version portion from a version
 * @param[in]      v                             version to extract from
 * @return the minor portion of the version number
 */
#define iot_version_minor( v ) ((v >> 16u) & 0xFF)

/**
 * @brief Extracts the patch version portion from a version
 * @param[in]      v                             version to extract from
 * @return the patch portion of the version number
 */
#define iot_version_patch( v ) ((v >> 8u) & 0xFF)

/**
 * @brief Extracts the tweak version portion from a version
 * @param[in]      v                             version to extract from
 * @return the tweak portion of the version number
 */
#define iot_version_tweak( v ) (v & 0xFF)

#ifdef __cplusplus
}
#endif /* ifdef __cplusplus */

#endif

