#!/bin/sh -x
# This script should be a noop for systems without btrfs
# -------------------------------
# 1. make sure this FS is btrfs
# 2. make sure fs tools exist
# -------------------------------
TRUE=1
FALSE=0
btrfs_enabled=FALSE
btrfs_fs=`mount |grep -c "/ type btrfs"`
if [ "$btrfs_fs" = "0" ]; then
	echo "Root partition is not btrfs, nothing to do"
else
	tools=`which btrfs`
	if [ -e "$tools" ]; then
		btrfs_enabled=TRUE
	fi
fi

# ---------------------------------
# get a timestamp for the snapshot
# ---------------------------------
if [ "$btrfs_enabled" = TRUE ]; then
	top_dir=`pwd`
	ns=`date +%N`

	current="snap_${ns}"

	# -----------------------------------------------------------------------------
	# Write the snapshot name to a file for use in error script.
	# note: btrfs doesn't include the first / in the name, but it does store it in
	# /....  So, when we query it later we don't use the /
	# -----------------------------------------------------------------------------
	snap_file=/current
	sudo touch $snap_file
	sudo chown iot:iot $snap_file
	echo $current > $snap_file

	# --------------------------------------
	# create a snapshot phase
	# --------------------------------------
	cd /
	echo "Creating snapshot..."
	sudo btrfs sub snap  / ${current}
	if [ "$?" != "0" ]; then
		echo "Error: snapshot failed"

		# now remove the generated name for the snapshot
		rm -f $snap_file
		exit 1
	fi
	sudo sync
fi

exit 0
