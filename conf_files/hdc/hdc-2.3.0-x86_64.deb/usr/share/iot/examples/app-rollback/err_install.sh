#!/bin/sh
# --------------------------------------------------------------------
# Restore phase:
# This script should be a noop for systems without btrfs
# --------------------------------------------------------------------
# 1. make sure this FS is btrfs
# 2. make sure fs tools exist
TRUE=1
FALSE=0
btrfs_enabled=FALSE
btrfs_fs=`mount |grep -c "/ type btrfs"`
if [ "$btrfs_fs" = "0" ]; then
	echo "Root partition is not btrfs, nothing to do"
else
	tools=`which btrfs`
	if [ -e "$tools" ]; then
		btrfs_enabled=TRUE
	fi
fi

# -------------------------------------------------------------------
# Add custom implementation here
# -------------------------------------------------------------------

# -------------------------------------------------------------------
# Restore: Do not do anything below this line
# -------------------------------------------------------------------
# the snapshot name was generated in pre phase and writtent to $snap_file
if [ "$btrfs_enabled" = TRUE ]; then

	snap_file=/current

	# add a check for BTRFS
	btrfs_fs=`mount |grep -c "/ type btrfs"`
	if [ "$btrfs_fs" = "0" ]; then
		echo "Root partition is not btrfs, exiting gracefully..."
		exit 0
	fi

	current=""

	# read the $snap_file to get the snapshot name
	echo "WARNING: something went wrong, rolling back to snapshot"
	if [ -e "$snap_file" ]; then
		current=`cat $snap_file`
		echo "Found snapshot name:$current"
	else
		echo "Error: $snap_file file found, cannot rollback"
		exit 1
	fi 

	# get the id of the snapshot and set it as the default, then reboot
	def_id=`sudo btrfs sub list / | grep $current | sed 's/ID \(.*\) gen.*/\1/'`
	echo "btrfs sub set-default $def_id /"
	sudo btrfs sub set-default $def_id /

	# print out some useful debugging info for the partitions
	echo "Listing snapshots..."
	sudo btrfs sub list /

	echo "Listing default..."
	sudo btrfs sub get-default /

	echo "Rebooting in 1 minute ..."
	sudo /sbin/shutdown -r +1
fi
