#!/bin/sh

echo "This is a rollback example, deleting the startup.bin credentials"

# Note: this is an example where something goes terribly wrong and bricks the
# device.  This is a destructive example.  If rollback succeeds, nothing will be
# changed.  If it does not, the device will be bricked.
sudo rm -fr /opt/intel/ccg/bin/*.bin
sudo touch /BROKEN
exit 1
