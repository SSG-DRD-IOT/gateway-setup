Complete api example
====================

This is an example application demonstrating advanced usage of the API for
IoT devices.

