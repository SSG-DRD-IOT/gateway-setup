#!/bin/bash
echo "command executed: $0 $@"
echo "result: $?" >&2
exit 0
