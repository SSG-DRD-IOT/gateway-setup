Actions example
===============

This is an example application for using the API for actions. This example
demonstrates the following API calls:

- iot_action_allocate
- iot_action_deregister
- iot_action_free
- iot_action_parameter_add
- iot_action_parameter_get
- iot_action_parameter_set
- iot_action_register_callback
- iot_action_register_command

