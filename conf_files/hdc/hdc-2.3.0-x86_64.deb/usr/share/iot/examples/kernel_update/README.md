Kernel Update Example
=====================

Last revision
--------------
Thursday, October 27th, 2016

Description
-------------
This document explains the example provided to do a kernel update and what is done in each step

Before one can start doing an upgrade, all the files to be upgraded have to be produced first. They can be rpm packages, binary files, or any other files. In this example only rpm packages will be used. The process of producing upgrade packages/files is beyond the scope of this document.

ota_manifest.spec
----------------------
This is the manifest file that contains the high level information about the update, the platform to update and the update package itself. A few things to note:

- "archive_format" has to be specified to match the compression type used to compress the update package and for this context, as kernel update is only supported for linux platforms, only ".tar.gz" is supported.
- "sha256" has to match the sha256sum of the update package, otherwise it is going to fail.
- The format of this file has to be preserved in order to be uploaded to ePO


```
{
        "manifest": {
                "identifier": "Wind River Software Update Manifest",
                "operation": "app-install",
                "release" : {
                        "version" : "kern_r1",
                        "type" : "licensed"
                },
                "platforms": [{
                        "product": "cpe:2.3:o:WindRiver:wrlinux:7.0.0.19:rcpl0019:*:en-US:*:hdc:intel-quark:*",
                        "mfr_vendor_id" : "WindRiver",
                        "mfr_device_id" : "IOT"
                }],
                "channelMode": "append",
                        "channels" : [{
                        "alias": "iot_ota",
                        "name": "WR OTA",
                        "type": "epo",
                        "archive_format":"tar.gz",
                        "url": "system-update.tar.gz",
                        "sha256": "9baab5d2c43601fda7ae8a476a53a65bc3ec2b0d90b87db3a32d527dee76e852",
                        "language": "0000"
                }],
                "packages": [{ "name": "system-update.rpm" } ],
                "rebootOnCompletion": "no"
        }
}

```

update.json
-------------
This file contains more detailed information about the update and what to be done in all phases of the update. There are 4 phases:

- pre_install
- install
- post_install
- error action

Error-action is only triggered if any of the first 3 phases failed. These phases can be single line commands or scripts; and the scripts can be of any kind as long as the device support it. It is user's responsibility to make sure that the command/script provided will be able to execute. In this example we don't care about executable permissions, since we call `sh <script_name>`

For this particular example, no error-action is specified. Hence there is no recovery scheme if the update fails. Reboot is set to "yes" as kernel update will require a reboot after the upgrade is completed.

```
{
    "name":"kernel module r2 update",
    "version":"2.0.0",
    "description":"Updating kernel module",
    "pre_install":"sh pre_install.sh kernel-module.tar.gz",
    "install":"sh install.sh",
    "post_install":"sh post_install.sh",
    "error_action":"",
    "reboot":"yes",
    "compatibility": {
            "os_version":  "cpe:2.3:o:WindRiver:wrlinux:7.0.0.15:rcpl0015:*:en-US:*:hdc:intel-quark:*",
            "mfg_device_id":  "device_regex",
            "mfg_vendor_id": "mfg_regex",
            "model_name":    "model_regex",
            "serial": "serial_num_regex"
    },
    "extra_key_value_ary": [ { "key":"value" }],
    "custom_obj": { }
}
```

pre_install.sh
-----------------
This is the phase in which all the preparations before an install are done. In this example the update package tarball will be unwinded; which results in rpm packages to be installed in install phase. It also checks if there is any rpm lock that could prevent the install of the rpm packages.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
RPM_LOCKS=/var/lib/rpm/__db.*
RPM_PACKAGE=$1
LOG_FILE=$BASE_DIR/update_kernel_r1.log

echo "Kernel update r1 pre-install..." >> $LOG_FILE
date >> $LOG_FILE

# unwind the tarball containing the rpm files
echo "Unwinding $RPM_PACKAGE" >> $LOG_FILE
tar xzvf $RPM_PACKAGE >> $LOG_FILE

# check if there is any rpm locks
if [ 0 -ne 'ls $RPM_LOCKS' ]
then
        echo "Deleting rpm locks..." >> $LOG_FILE
        sudo rm -f $RPM_LOCKS
fi

echo "Pre-install succeeded. Exiting..." >> $LOG_FILE
exit 0
```


install.sh
-----------
This is where the installation happens. Here all the rpm packages are installed one at a time untill all of them are installed unless there is a failure with one of them. And then the mount point and mount partition has to be synced for the kernel updates to take effect.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_kernel_r1.log
MOUNT_POINT=/mnt/vfat

echo "Kernel update r1 install..." >> $LOG_FILE
date >> $LOG_FILE

# install the rpm
echo "Installing rpm files..." >> $LOG_FILE
for rpm_file in *.rpm
do
        echo "Installing $rpm_file..." >> $LOG_FILE
        sudo rpm -Uvh --nodeps $rpm_file >> $LOG_FILE
        if [ 0 -ne $? ]
        then
                echo "Failed to install $rpm_file. Exitting..." >> $LOG_FILE
                exit $?
        fi
done

# Creating mount point
echo "Creating mount point ($MOUNT_POINT)..." >> $LOG_FILE
sudo mkdir -p $MOUNT_POINT >> $LOG_FILE

# Determine the device containing the VFAT partition
echo "Determining mount partition..." >> $LOG_FILE
MOUNT_PART=$(sudo /usr/sbin/lvs --noheadings --nosuffix -o devices | sed -n "s/^ *//; s/ *$//; s/(.*)//; 1p" | sed -e "s/2$/1/")
MOUNT_PART=${MOUNT_PART%1}
echo "Mount partition is $MOUNT_PART" >> $LOG_FILE

# make sure vfat partition is not mounted
echo "Unmounting mount partition ($MOUNT_PART) in case it is already mounted..." >> $LOG_FILE
sudo /bin/umount -f $MOUNT_PART >> $LOG_FILE

# make sure mount point is not mounted
echo "Unmounting mount point ($MOUNT_POINT) in case it is already mounted..." >> $LOG_FILE
sudo /bin/umount -f $MOUNT_POINT >> $LOG_FILE

# mount the vfat partition
echo "Mounting mount partition ($MOUNT_PART) to mount point ($MOUNT_POINT)" >> $LOG_FILE
sudo /bin/mount $MOUNT_PART $MOUNT_POINT >> $LOG_FILE

# umount vfat partition
echo "Syncing and unmounting mount point ($MOUNT_POINT)"  >> $LOG_FILE
sync && sudo /bin/umount -f $MOUNT_POINT >> $LOG_FILE

echo "Install succeded. Exitting..." >> $LOG_FILE
exit 0
```

post_install.sh
-----------------
In this phase, users can do cleanup of all the artifacts produced during the update and possibly make sure if the update was successful. In this example, only the log files produced during the update is moved to the upload directory so it can be retrieved by users.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_kernel_r1.log
UPLOAD_DIR=/var/lib/iot/upload/

if [ -e "$LOG_FILE" ]
then
        echo "Kernel update r1 post-install..." >> $LOG_FILE
        date >> $LOG_FILE
        echo "Moving $LOG_FILE to $UPLOAD_DIR">> $LOG_FILE
        mv "$LOG_FILE" "$UPLOAD_DIR" >> $LOG_FILE
        echo "Post-install succeded. Exitting..."
        exit 0
else
        exit 1
fi
```

kernel-module.tar.gz
-----------------------
This is just the tarball containing all the rpm packages to be updated. Here is a list of what it contains:
```
kernel-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm
kernel-image-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm
kernel-module-6lowpan-iphc-3.14-r1.1.intel_quark.rpm
kernel-module-ac97-bus-3.14-r1.1.intel_quark.rpm
kernel-module-ad7298-3.14-r1.1.intel_quark.rpm
kernel-module-adc1x8s102-3.14-r1.1.intel_quark.rpm
kernel-module-bluetooth-3.14-r1.1.intel_quark.rpm
kernel-module-btusb-3.14-r1.1.intel_quark.rpm
kernel-module-button-3.14-r1.1.intel_quark.rpm
kernel-module-can-3.14-r1.1.intel_quark.rpm
kernel-module-can-bcm-3.14-r1.1.intel_quark.rpm
kernel-module-can-gw-3.14-r1.1.intel_quark.rpm
kernel-module-can-j1939-3.14-r1.1.intel_quark.rpm
kernel-module-can-raw-3.14-r1.1.intel_quark.rpm
kernel-module-cdc-acm-3.14-r1.1.intel_quark.rpm
kernel-module-cfg80211-3.14-r1.1.intel_quark.rpm
kernel-module-chipreg-3.14-r1.1.intel_quark.rpm
kernel-module-cn-3.14-r1.1.intel_quark.rpm
kernel-module-cpuid-3.14-r1.1.intel_quark.rpm
kernel-module-crc-itu-t-3.14-r1.1.intel_quark.rpm
kernel-module-cryptoloop-3.14-r1.1.intel_quark.rpm
kernel-module-cy8c9540a-3.14-r1.1.intel_quark.rpm
kernel-module-dac7564-3.14-r1.1.intel_quark.rpm
kernel-module-dw-dmac-3.14-r1.1.intel_quark.rpm
kernel-module-dw-dmac-core-3.14-r1.1.intel_quark.rpm
kernel-module-efi-capsule-update-3.14-r1.1.intel_quark.rpm
kernel-module-evdev-3.14-r1.1.intel_quark.rpm
kernel-module-f75111-3.14-r1.1.intel_quark.rpm
kernel-module-g-acm-ms-3.14-r1.1.intel_quark.rpm
kernel-module-g-ether-3.14-r1.1.intel_quark.rpm
kernel-module-g-mass-storage-3.14-r1.1.intel_quark.rpm
kernel-module-gpio-pca953x-3.14-r1.1.intel_quark.rpm
kernel-module-gpio-sch-3.14-r1.1.intel_quark.rpm
kernel-module-g-serial-3.14-r1.1.intel_quark.rpm
kernel-module-hci-vhci-3.14-r1.1.intel_quark.rpm
kernel-module-hid-3.14-r1.1.intel_quark.rpm
kernel-module-hid-generic-3.14-r1.1.intel_quark.rpm
kernel-module-i2c-algo-bit-3.14-r1.1.intel_quark.rpm
kernel-module-igb-3.14-r1.1.intel_quark.rpm
kernel-module-iio-trig-hrtimer-3.14-r1.1.intel_quark.rpm
kernel-module-iio-trig-sysfs-3.14-r1.1.intel_quark.rpm
kernel-module-industrialio-3.14-r1.1.intel_quark.rpm
kernel-module-industrialio-triggered-buffer-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-audio-ctrl-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-gip-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-gip-test-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-thermal-3.14-r1.1.intel_quark.rpm
kernel-module-iwldvm-3.14-r1.1.intel_quark.rpm
kernel-module-iwlmvm-3.14-r1.1.intel_quark.rpm
kernel-module-iwlwifi-3.14-r1.1.intel_quark.rpm
kernel-module-jffs2-3.14-r1.1.intel_quark.rpm
kernel-module-kfifo-buf-3.14-r1.1.intel_quark.rpm
kernel-module-led-class-3.14-r1.1.intel_quark.rpm
kernel-module-libcomposite-3.14-r1.1.intel_quark.rpm
kernel-module-lis331dlh-intel-qrk-3.14-r1.1.intel_quark.rpm
kernel-module-loop-3.14-r1.1.intel_quark.rpm
kernel-module-m25p80-3.14-r1.1.intel_quark.rpm
kernel-module-mac80211-3.14-r1.1.intel_quark.rpm
kernel-module-minix-3.14-r1.1.intel_quark.rpm
kernel-module-mousedev-3.14-r1.1.intel_quark.rpm
kernel-module-msr-3.14-r1.1.intel_quark.rpm
kernel-module-mtd-3.14-r1.1.intel_quark.rpm
kernel-module-mtd-blkdevs-3.14-r1.1.intel_quark.rpm
kernel-module-mtdblock-3.14-r1.1.intel_quark.rpm
kernel-module-pca9685-3.14-r1.1.intel_quark.rpm
kernel-module-pch-gpio-vbus-3.14-r1.1.intel_quark.rpm
kernel-module-pch-udc-3.14-r1.1.intel_quark.rpm
kernel-module-processor-3.14-r1.1.intel_quark.rpm
kernel-module-qcserial-3.14-r1.1.intel_quark.rpm
kernel-module-regmap-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-regmap-spi-3.14-r1.1.intel_quark.rpm
kernel-module-reiserfs-3.14-r1.1.intel_quark.rpm
kernel-module-rfkill-3.14-r1.1.intel_quark.rpm
kernel-module-rt2x00lib-3.14-r1.1.intel_quark.rpm
kernel-module-rt2x00usb-3.14-r1.1.intel_quark.rpm
kernel-module-rt73usb-3.14-r1.1.intel_quark.rpm
kernel-modules-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-spi-3.14-r1.1.intel_quark.rpm
kernel-module-sha512-generic-3.14-r1.1.intel_quark.rpm
kernel-module-slcan-3.14-r1.1.intel_quark.rpm
kernel-module-snd-3.14-r1.1.intel_quark.rpm
kernel-module-snd-ac97-codec-3.14-r1.1.intel_quark.rpm
kernel-module-snd-ens1370-3.14-r1.1.intel_quark.rpm
kernel-module-snd-hwdep-3.14-r1.1.intel_quark.rpm
kernel-module-snd-intel8x0-3.14-r1.1.intel_quark.rpm
kernel-module-snd-mixer-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-pcm-3.14-r1.1.intel_quark.rpm
kernel-module-snd-pcm-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-rawmidi-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-device-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-midi-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-midi-event-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-timer-3.14-r1.1.intel_quark.rpm
kernel-module-snd-usb-audio-3.14-r1.1.intel_quark.rpm
kernel-module-snd-usbmidi-lib-3.14-r1.1.intel_quark.rpm
kernel-module-soundcore-3.14-r1.1.intel_quark.rpm
kernel-module-spi-bitbang-3.14-r1.1.intel_quark.rpm
kernel-module-spi-gpio-3.14-r1.1.intel_quark.rpm
kernel-module-spi-pxa2xx-pci-3.14-r1.1.intel_quark.rpm
kernel-module-spi-pxa2xx-platform-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-spi-3.14-r1.1.intel_quark.rpm
kernel-module-tcrypt-3.14-r1.1.intel_quark.rpm
kernel-module-thermal-3.14-r1.1.intel_quark.rpm
kernel-module-udc-core-3.14-r1.1.intel_quark.rpm
kernel-module-u-ether-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-acm-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-ecm-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-ecm-subset-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-mass-storage-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-obex-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-rndis-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-serial-3.14-r1.1.intel_quark.rpm
kernel-module-usbhid-3.14-r1.1.intel_quark.rpm
kernel-module-usb-wwan-3.14-r1.1.intel_quark.rpm
kernel-module-u-serial-3.14-r1.1.intel_quark.rpm
kernel-module-vcan-3.14-r1.1.intel_quark.rpm
```

Log file
----------
There are 2 log files produced from this example, one from iot itself and another one created by all the install scripts provided. 

iot_install_updates.log
```
Executing command 'mkdir -p /var/lib/iot/update/downloads'
Command executed successfully: 
INFO:
Executing command 'which sadmin'
Failed to execute the command:  which: no sadmin in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)

Command error:
which: no sadmin in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)

INFO: MEC tools not found.
INFO: MEC tools do not exist.  No MEC operations will be run.
INFO: disable security SUCCESS
 EPO manifest context ok 
INFO: operation: local-install
Identifier               : Wind River Software Update Manifest

Operation                : local-install

Release->version         : kern_r1

Release->type            : licensed

Platforms->product       : cpe:2.3:o:WindRiver:wrlinux:7.0.0.19:rcpl0019:*:en-US:*:hdc:intel-quark:*

Platforms->mfr_vendor_id : WindRiver

Platforms->mfr_device_id : IOT

Channel Mode             : append

Channels->alias          : iot_ota

Channels->name           : WR OTA

Channels->type           : epo

Channels->url            : http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_kern_r1/local-install/0000/system-update.tar.gz

Channels->sha256         : 9baab5d2c43601fda7ae8a476a53a65bc3ec2b0d90b87db3a32d527dee76e852

Channels->language       : 0000

Packages                 : 

	system-update.rpm

RebootOnCompletion       : no


================================================
2016-10-19 19:45:47.378719:
Fetching the Update Package ... Start!
================================================

INFO: downloading pkg from uri: http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_kern_r1/local-install/0000/system-update.tar.gz
pkg_uri = http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_kern_r1/local-install/0000/system-update.tar.gz
Downloading http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_kern_r1/local-install/0000/system-update.tar.gz to local file /var/lib/iot/update/downloads/update_pkg.tar.gz
INFO: Validating checksum on file /var/lib/iot/update/downloads/update_pkg.tar.gz

INFO: expected 9baab5d2c43601fda7ae8a476a53a65bc3ec2b0d90b87db3a32d527dee76e852

INFO: calculated 9baab5d2c43601fda7ae8a476a53a65bc3ec2b0d90b87db3a32d527dee76e852


================================================
2016-10-19 19:46:00.988066:
Fetching the Update Package ... Successful!
 
================================================

INFO: sha checksum OK

================================================
2016-10-19 19:46:00.990351:
Unarchiving the Update Package ... Start!
================================================

Executing command 'cd /var/lib/iot/update/downloads && tar xzvf /var/lib/iot/update/downloads/update_pkg.tar.gz'
Command executed successfully: install.sh
kernel-module.tar.gz
post_install.sh
pre_install.sh
update.json


================================================
2016-10-19 19:46:05.050019:
Unarchiving the Update Package ... Successful!
================================================

 update manifest context ok 

==============================================
Software Update Package

name                         : kernel module r2 update

version                      : 2.0.0

description                  : Updating kernel module

pre_install                  : sh pre_install.sh

install                      : sh install.sh

post_install                 : sh post_install.sh

error_action                 : 

reboot                       : yes

compatibility                :

   os_version       : cpe:2.3:o:WindRiver:wrlinux:7.0.0.15:rcpl0015:*:en-US:*:hdc:intel-quark:*

   mfg_device_id       : device_regex

   mfg_vendor_id       : mfg_regex

   serial       : serial_num_regex

   model_name       : model_regex

extra_key_value_ary          :

   {u'key': u'value'} 

custom_obj                   :

================================================

================================================
2016-10-19 19:46:05.109770:
Determing Device Compatibility
================================================


================================================
2016-10-19 19:46:05.117889:
Executing pre-install ... start !
================================================

script sudo  sh pre_install.sh
Executing command 'sudo sh pre_install.sh'

================================================
2016-10-19 19:46:11.870127:
Executing pre-install ... Successful !
================================================


================================================
2016-10-19 19:46:11.873020:
Executing install ... start !
================================================

Executing command 'sudo sh install.sh'
Command executed successfully: depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
depmod: ERROR: Module 'hci_vhci' has devname (vhci) but lacks major and minor information. Ignoring.
umount: /dev/mmcblk0p: mountpoint not found
umount: /mnt/vfat: not mounted
mount: special device /dev/mmcblk0p does not exist
umount: /mnt/vfat: not mounted


================================================
2016-10-19 21:00:18.283333:
Executing install ... Successful !
================================================


================================================
2016-10-19 21:00:18.285881:
Executing post_install ... start !
================================================

Executing command 'sudo sh post_install.sh'
Command executed successfully: Post-install succeded. Exitting...


================================================
2016-10-19 21:00:18.453344:
Executing post_install ... Successful !
================================================

INFO: MEC security in original state

Executing command 'sudo cp /var/lib/iot/update/iot_install_updates.log /var/lib/iot/upload'
```

update_kernel_r1.log:
```
Kernel update r1 pre-install...
Wed Oct 19 19:46:06 UTC 2016
Unwinding kernel-module.tar.gz
kernel-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm
kernel-image-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm
kernel-module-6lowpan-iphc-3.14-r1.1.intel_quark.rpm
kernel-module-ac97-bus-3.14-r1.1.intel_quark.rpm
kernel-module-ad7298-3.14-r1.1.intel_quark.rpm
kernel-module-adc1x8s102-3.14-r1.1.intel_quark.rpm
kernel-module-bluetooth-3.14-r1.1.intel_quark.rpm
kernel-module-btusb-3.14-r1.1.intel_quark.rpm
kernel-module-button-3.14-r1.1.intel_quark.rpm
kernel-module-can-3.14-r1.1.intel_quark.rpm
kernel-module-can-bcm-3.14-r1.1.intel_quark.rpm
kernel-module-can-gw-3.14-r1.1.intel_quark.rpm
kernel-module-can-j1939-3.14-r1.1.intel_quark.rpm
kernel-module-can-raw-3.14-r1.1.intel_quark.rpm
kernel-module-cdc-acm-3.14-r1.1.intel_quark.rpm
kernel-module-cfg80211-3.14-r1.1.intel_quark.rpm
kernel-module-chipreg-3.14-r1.1.intel_quark.rpm
kernel-module-cn-3.14-r1.1.intel_quark.rpm
kernel-module-cpuid-3.14-r1.1.intel_quark.rpm
kernel-module-crc-itu-t-3.14-r1.1.intel_quark.rpm
kernel-module-cryptoloop-3.14-r1.1.intel_quark.rpm
kernel-module-cy8c9540a-3.14-r1.1.intel_quark.rpm
kernel-module-dac7564-3.14-r1.1.intel_quark.rpm
kernel-module-dw-dmac-3.14-r1.1.intel_quark.rpm
kernel-module-dw-dmac-core-3.14-r1.1.intel_quark.rpm
kernel-module-efi-capsule-update-3.14-r1.1.intel_quark.rpm
kernel-module-evdev-3.14-r1.1.intel_quark.rpm
kernel-module-f75111-3.14-r1.1.intel_quark.rpm
kernel-module-g-acm-ms-3.14-r1.1.intel_quark.rpm
kernel-module-g-ether-3.14-r1.1.intel_quark.rpm
kernel-module-g-mass-storage-3.14-r1.1.intel_quark.rpm
kernel-module-gpio-pca953x-3.14-r1.1.intel_quark.rpm
kernel-module-gpio-sch-3.14-r1.1.intel_quark.rpm
kernel-module-g-serial-3.14-r1.1.intel_quark.rpm
kernel-module-hci-vhci-3.14-r1.1.intel_quark.rpm
kernel-module-hid-3.14-r1.1.intel_quark.rpm
kernel-module-hid-generic-3.14-r1.1.intel_quark.rpm
kernel-module-i2c-algo-bit-3.14-r1.1.intel_quark.rpm
kernel-module-igb-3.14-r1.1.intel_quark.rpm
kernel-module-iio-trig-hrtimer-3.14-r1.1.intel_quark.rpm
kernel-module-iio-trig-sysfs-3.14-r1.1.intel_quark.rpm
kernel-module-industrialio-3.14-r1.1.intel_quark.rpm
kernel-module-industrialio-triggered-buffer-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-audio-ctrl-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-gip-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-gip-test-3.14-r1.1.intel_quark.rpm
kernel-module-intel-qrk-thermal-3.14-r1.1.intel_quark.rpm
kernel-module-iwldvm-3.14-r1.1.intel_quark.rpm
kernel-module-iwlmvm-3.14-r1.1.intel_quark.rpm
kernel-module-iwlwifi-3.14-r1.1.intel_quark.rpm
kernel-module-jffs2-3.14-r1.1.intel_quark.rpm
kernel-module-kfifo-buf-3.14-r1.1.intel_quark.rpm
kernel-module-led-class-3.14-r1.1.intel_quark.rpm
kernel-module-libcomposite-3.14-r1.1.intel_quark.rpm
kernel-module-lis331dlh-intel-qrk-3.14-r1.1.intel_quark.rpm
kernel-module-loop-3.14-r1.1.intel_quark.rpm
kernel-module-m25p80-3.14-r1.1.intel_quark.rpm
kernel-module-mac80211-3.14-r1.1.intel_quark.rpm
kernel-module-minix-3.14-r1.1.intel_quark.rpm
kernel-module-mousedev-3.14-r1.1.intel_quark.rpm
kernel-module-msr-3.14-r1.1.intel_quark.rpm
kernel-module-mtd-3.14-r1.1.intel_quark.rpm
kernel-module-mtd-blkdevs-3.14-r1.1.intel_quark.rpm
kernel-module-mtdblock-3.14-r1.1.intel_quark.rpm
kernel-module-pca9685-3.14-r1.1.intel_quark.rpm
kernel-module-pch-gpio-vbus-3.14-r1.1.intel_quark.rpm
kernel-module-pch-udc-3.14-r1.1.intel_quark.rpm
kernel-module-processor-3.14-r1.1.intel_quark.rpm
kernel-module-qcserial-3.14-r1.1.intel_quark.rpm
kernel-module-regmap-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-regmap-spi-3.14-r1.1.intel_quark.rpm
kernel-module-reiserfs-3.14-r1.1.intel_quark.rpm
kernel-module-rfkill-3.14-r1.1.intel_quark.rpm
kernel-module-rt2x00lib-3.14-r1.1.intel_quark.rpm
kernel-module-rt2x00usb-3.14-r1.1.intel_quark.rpm
kernel-module-rt73usb-3.14-r1.1.intel_quark.rpm
kernel-modules-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-sc16is7xx-spi-3.14-r1.1.intel_quark.rpm
kernel-module-sha512-generic-3.14-r1.1.intel_quark.rpm
kernel-module-slcan-3.14-r1.1.intel_quark.rpm
kernel-module-snd-3.14-r1.1.intel_quark.rpm
kernel-module-snd-ac97-codec-3.14-r1.1.intel_quark.rpm
kernel-module-snd-ens1370-3.14-r1.1.intel_quark.rpm
kernel-module-snd-hwdep-3.14-r1.1.intel_quark.rpm
kernel-module-snd-intel8x0-3.14-r1.1.intel_quark.rpm
kernel-module-snd-mixer-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-pcm-3.14-r1.1.intel_quark.rpm
kernel-module-snd-pcm-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-rawmidi-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-device-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-midi-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-midi-event-3.14-r1.1.intel_quark.rpm
kernel-module-snd-seq-oss-3.14-r1.1.intel_quark.rpm
kernel-module-snd-timer-3.14-r1.1.intel_quark.rpm
kernel-module-snd-usb-audio-3.14-r1.1.intel_quark.rpm
kernel-module-snd-usbmidi-lib-3.14-r1.1.intel_quark.rpm
kernel-module-soundcore-3.14-r1.1.intel_quark.rpm
kernel-module-spi-bitbang-3.14-r1.1.intel_quark.rpm
kernel-module-spi-gpio-3.14-r1.1.intel_quark.rpm
kernel-module-spi-pxa2xx-pci-3.14-r1.1.intel_quark.rpm
kernel-module-spi-pxa2xx-platform-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-i2c-3.14-r1.1.intel_quark.rpm
kernel-module-st-sensors-spi-3.14-r1.1.intel_quark.rpm
kernel-module-tcrypt-3.14-r1.1.intel_quark.rpm
kernel-module-thermal-3.14-r1.1.intel_quark.rpm
kernel-module-udc-core-3.14-r1.1.intel_quark.rpm
kernel-module-u-ether-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-acm-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-ecm-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-ecm-subset-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-mass-storage-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-obex-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-rndis-3.14-r1.1.intel_quark.rpm
kernel-module-usb-f-serial-3.14-r1.1.intel_quark.rpm
kernel-module-usbhid-3.14-r1.1.intel_quark.rpm
kernel-module-usb-wwan-3.14-r1.1.intel_quark.rpm
kernel-module-u-serial-3.14-r1.1.intel_quark.rpm
kernel-module-vcan-3.14-r1.1.intel_quark.rpm
Pre-install succedded. Exitting...
Kernel update r1 install...
Wed Oct 19 19:46:12 UTC 2016
Installing rpm files...
Installing kernel-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-3.14.39ltsi-wr7.0.0.1##################################################
Installing kernel-image-3.14.39ltsi-wr7.0.0.19-standard-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-image-3.14.39ltsi-wr7##################################################
update-alternatives: Linking //boot/bzImage to /boot/bzImage-3.14.39ltsi-WR7.0.0.19_standard
Installing kernel-module-6lowpan-iphc-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-6lowpan-iphc  ##################################################
Installing kernel-module-ac97-bus-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-ac97-bus      ##################################################
Installing kernel-module-ad7298-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-ad7298        ##################################################
Installing kernel-module-adc1x8s102-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-adc1x8s102    ##################################################
Installing kernel-module-bluetooth-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-bluetooth     ##################################################
Installing kernel-module-btusb-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-btusb         ##################################################
Installing kernel-module-button-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-button        ##################################################
Installing kernel-module-can-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-can           ##################################################
Installing kernel-module-can-bcm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-can-bcm       ##################################################
Installing kernel-module-can-gw-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-can-gw        ##################################################
Installing kernel-module-can-j1939-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-can-j1939     ##################################################
Installing kernel-module-can-raw-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-can-raw       ##################################################
Installing kernel-module-cdc-acm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cdc-acm       ##################################################
Installing kernel-module-cfg80211-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cfg80211      ##################################################
Installing kernel-module-chipreg-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-chipreg       ##################################################
Installing kernel-module-cn-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cn            ##################################################
Installing kernel-module-cpuid-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cpuid         ##################################################
Installing kernel-module-crc-itu-t-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-crc-itu-t     ##################################################
Installing kernel-module-cryptoloop-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cryptoloop    ##################################################
Installing kernel-module-cy8c9540a-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-cy8c9540a     ##################################################
Installing kernel-module-dac7564-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-dac7564       ##################################################
Installing kernel-module-dw-dmac-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-dw-dmac       ##################################################
Installing kernel-module-dw-dmac-core-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-dw-dmac-core  ##################################################
Installing kernel-module-efi-capsule-update-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-efi-capsule-up##################################################
Installing kernel-module-evdev-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-evdev         ##################################################
Installing kernel-module-f75111-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-f75111        ##################################################
Installing kernel-module-g-acm-ms-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-g-acm-ms      ##################################################
Installing kernel-module-g-ether-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-g-ether       ##################################################
Installing kernel-module-g-mass-storage-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-g-mass-storage##################################################
Installing kernel-module-g-serial-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-g-serial      ##################################################
Installing kernel-module-gpio-pca953x-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-gpio-pca953x  ##################################################
Installing kernel-module-gpio-sch-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-gpio-sch      ##################################################
Installing kernel-module-hci-vhci-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-hci-vhci      ##################################################
Installing kernel-module-hid-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-hid           ##################################################
Installing kernel-module-hid-generic-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-hid-generic   ##################################################
Installing kernel-module-i2c-algo-bit-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-i2c-algo-bit  ##################################################
Installing kernel-module-igb-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-igb           ##################################################
Installing kernel-module-iio-trig-hrtimer-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-iio-trig-hrtim##################################################
Installing kernel-module-iio-trig-sysfs-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-iio-trig-sysfs##################################################
Installing kernel-module-industrialio-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-industrialio  ##################################################
Installing kernel-module-industrialio-triggered-buffer-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-industrialio-t##################################################
Installing kernel-module-intel-qrk-audio-ctrl-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-intel-qrk-audi##################################################
Installing kernel-module-intel-qrk-gip-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-intel-qrk-gip ##################################################
Installing kernel-module-intel-qrk-gip-test-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-intel-qrk-gip-##################################################
Installing kernel-module-intel-qrk-thermal-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-intel-qrk-ther##################################################
Installing kernel-module-iwldvm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-iwldvm        ##################################################
Installing kernel-module-iwlmvm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-iwlmvm        ##################################################
Installing kernel-module-iwlwifi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-iwlwifi       ##################################################
Installing kernel-module-jffs2-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-jffs2         ##################################################
Installing kernel-module-kfifo-buf-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-kfifo-buf     ##################################################
Installing kernel-module-led-class-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-led-class     ##################################################
Installing kernel-module-libcomposite-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-libcomposite  ##################################################
Installing kernel-module-lis331dlh-intel-qrk-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-lis331dlh-inte##################################################
Installing kernel-module-loop-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-loop          ##################################################
Installing kernel-module-m25p80-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-m25p80        ##################################################
Installing kernel-module-mac80211-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-mac80211      ##################################################
Installing kernel-module-minix-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-minix         ##################################################
Installing kernel-module-mousedev-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-mousedev      ##################################################
Installing kernel-module-msr-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-msr           ##################################################
Installing kernel-module-mtd-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-mtd           ##################################################
Installing kernel-module-mtd-blkdevs-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-mtd-blkdevs   ##################################################
Installing kernel-module-mtdblock-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-mtdblock      ##################################################
Installing kernel-module-pca9685-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-pca9685       ##################################################
Installing kernel-module-pch-gpio-vbus-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-pch-gpio-vbus ##################################################
Installing kernel-module-pch-udc-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-pch-udc       ##################################################
Installing kernel-module-processor-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-processor     ##################################################
Installing kernel-module-qcserial-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-qcserial      ##################################################
Installing kernel-module-regmap-i2c-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-regmap-i2c    ##################################################
Installing kernel-module-regmap-spi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-regmap-spi    ##################################################
Installing kernel-module-reiserfs-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-reiserfs      ##################################################
Installing kernel-module-rfkill-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-rfkill        ##################################################
Installing kernel-module-rt2x00lib-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-rt2x00lib     ##################################################
Installing kernel-module-rt2x00usb-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-rt2x00usb     ##################################################
Installing kernel-module-rt73usb-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-rt73usb       ##################################################
Installing kernel-module-sc16is7xx-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-sc16is7xx     ##################################################
Installing kernel-module-sc16is7xx-i2c-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-sc16is7xx-i2c ##################################################
Installing kernel-module-sc16is7xx-spi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-sc16is7xx-spi ##################################################
Installing kernel-module-sha512-generic-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-sha512-generic##################################################
Installing kernel-module-slcan-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-slcan         ##################################################
Installing kernel-module-snd-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd           ##################################################
Installing kernel-module-snd-ac97-codec-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-ac97-codec##################################################
Installing kernel-module-snd-ens1370-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-ens1370   ##################################################
Installing kernel-module-snd-hwdep-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-hwdep     ##################################################
Installing kernel-module-snd-intel8x0-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-intel8x0  ##################################################
Installing kernel-module-snd-mixer-oss-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-mixer-oss ##################################################
Installing kernel-module-snd-pcm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-pcm       ##################################################
Installing kernel-module-snd-pcm-oss-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-pcm-oss   ##################################################
Installing kernel-module-snd-rawmidi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-rawmidi   ##################################################
Installing kernel-module-snd-seq-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-seq       ##################################################
Installing kernel-module-snd-seq-device-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-seq-device##################################################
Installing kernel-module-snd-seq-midi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-seq-midi  ##################################################
Installing kernel-module-snd-seq-midi-event-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-seq-midi-e##################################################
Installing kernel-module-snd-seq-oss-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-seq-oss   ##################################################
Installing kernel-module-snd-timer-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-timer     ##################################################
Installing kernel-module-snd-usb-audio-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-usb-audio ##################################################
Installing kernel-module-snd-usbmidi-lib-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-snd-usbmidi-li##################################################
Installing kernel-module-soundcore-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-soundcore     ##################################################
Installing kernel-module-spi-bitbang-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-spi-bitbang   ##################################################
Installing kernel-module-spi-gpio-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-spi-gpio      ##################################################
Installing kernel-module-spi-pxa2xx-pci-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-spi-pxa2xx-pci##################################################
Installing kernel-module-spi-pxa2xx-platform-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-spi-pxa2xx-pla##################################################
Installing kernel-module-st-sensors-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-st-sensors    ##################################################
Installing kernel-module-st-sensors-i2c-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-st-sensors-i2c##################################################
Installing kernel-module-st-sensors-spi-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-st-sensors-spi##################################################
Installing kernel-module-tcrypt-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-tcrypt        ##################################################
Installing kernel-module-thermal-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-thermal       ##################################################
Installing kernel-module-u-ether-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-u-ether       ##################################################
Installing kernel-module-u-serial-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-u-serial      ##################################################
Installing kernel-module-udc-core-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-udc-core      ##################################################
Installing kernel-module-usb-f-acm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-acm     ##################################################
Installing kernel-module-usb-f-ecm-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-ecm     ##################################################
Installing kernel-module-usb-f-ecm-subset-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-ecm-subs##################################################
Installing kernel-module-usb-f-mass-storage-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-mass-sto##################################################
Installing kernel-module-usb-f-obex-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-obex    ##################################################
Installing kernel-module-usb-f-rndis-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-rndis   ##################################################
Installing kernel-module-usb-f-serial-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-f-serial  ##################################################
Installing kernel-module-usb-wwan-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usb-wwan      ##################################################
Installing kernel-module-usbhid-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-usbhid        ##################################################
Installing kernel-module-vcan-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-module-vcan          ##################################################
Installing kernel-modules-3.14-r1.1.intel_quark.rpm...
Preparing...                ##################################################
kernel-modules              ##################################################
Creating mount point (/mnt/vfat)...
Determining mount partition...
Mount partition is /dev/mmcblk0p
Unmounting mount partition (/dev/mmcblk0p) in case it is already mounted...
Unmounting mount point (/mnt/vfat) in case it is already mounted...
Mounting mount partition (/dev/mmcblk0p) to mount point (/mnt/vfat)
Syncing and unmounting mount point (/mnt/vfat)
Install succeded. Exitting...
Kernel update r1 post-install...
Wed Oct 19 21:00:18 UTC 2016
Moving /var/lib/iot/update/update_kernel_r1.log to /var/lib/iot/upload/

```

Result
--------
On the device before the upgrade here is the list of all the kernel modules:
```
root@WR-LX-6D80:~# rpm -qa | grep kernel-module
kernel-module-industrialio-3.14-r0.1.intel_quark
kernel-module-hid-3.14-r0.1.intel_quark
kernel-module-button-3.14-r0.1.intel_quark
kernel-module-pch-gpio-vbus-3.14-r0.1.intel_quark
kernel-module-intel-qrk-gip-test-3.14-r0.1.intel_quark
kernel-module-tcrypt-3.14-r0.1.intel_quark
kernel-module-spi-pxa2xx-pci-3.14-r0.1.intel_quark
kernel-module-cy8c9540a-3.14-r0.1.intel_quark
kernel-module-mousedev-3.14-r0.1.intel_quark
kernel-module-chipreg-3.14-r0.1.intel_quark
kernel-module-thermal-3.14-r0.1.intel_quark
kernel-module-intel-qrk-audio-ctrl-3.14-r0.1.intel_quark
kernel-module-spi-pxa2xx-platform-3.14-r0.1.intel_quark
kernel-module-intel-qrk-gip-3.14-r0.1.intel_quark
kernel-module-loop-3.14-r0.1.intel_quark
kernel-module-processor-3.14-r0.1.intel_quark
kernel-module-slcan-3.14-r0.1.intel_quark
kernel-module-intel-qrk-thermal-3.14-r0.1.intel_quark
kernel-module-spi-bitbang-3.14-r0.1.intel_quark
kernel-module-usb-wwan-3.14-r0.1.intel_quark
kernel-module-efi-capsule-update-3.14-r0.1.intel_quark
kernel-module-u-ether-3.14-r0.1.intel_quark
kernel-module-vcan-3.14-r0.1.intel_quark
kernel-module-sha512-generic-3.14-r0.1.intel_quark
kernel-module-i2c-algo-bit-3.14-r0.1.intel_quark
kernel-module-led-class-3.14-r0.1.intel_quark
kernel-module-dw-dmac-core-3.14-r0.1.intel_quark
kernel-module-soundcore-3.14-r0.1.intel_quark
kernel-module-reiserfs-3.14-r0.1.intel_quark
kernel-module-st-sensors-i2c-3.14-r0.1.intel_quark
kernel-module-minix-3.14-r0.1.intel_quark
kernel-module-ac97-bus-3.14-r0.1.intel_quark
kernel-module-can-dev-3.14-r0.1.intel_quark
kernel-module-sc16is7xx-3.14-r0.1.intel_quark
kernel-module-crc-itu-t-3.14-r0.1.intel_quark
kernel-module-st-sensors-spi-3.14-r0.1.intel_quark
kernel-module-regmap-i2c-3.14-r0.1.intel_quark
kernel-module-6lowpan-iphc-3.14-r0.1.intel_quark
kernel-module-mtd-3.14-r0.1.intel_quark
kernel-module-cpuid-3.14-r0.1.intel_quark
kernel-module-cdc-acm-3.14-r0.1.intel_quark
kernel-module-gpio-pca953x-3.14-r0.1.intel_quark
kernel-module-rfkill-3.14-r0.1.intel_quark
kernel-module-udc-core-3.14-r0.1.intel_quark
kernel-module-evdev-3.14-r0.1.intel_quark
kernel-module-msr-3.14-r0.1.intel_quark
kernel-module-regmap-spi-3.14-r0.1.intel_quark
kernel-module-cn-3.14-r0.1.intel_quark
kernel-module-gpio-sch-3.14-r0.1.intel_quark
kernel-module-can-3.14-r0.1.intel_quark
kernel-module-u-serial-3.14-r0.1.intel_quark
kernel-module-dac7564-3.14-r0.1.intel_quark
kernel-module-st-sensors-3.14-r0.1.intel_quark
kernel-module-kfifo-buf-3.14-r0.1.intel_quark
kernel-module-iio-trig-hrtimer-3.14-r0.1.intel_quark
kernel-module-iio-trig-sysfs-3.14-r0.1.intel_quark
kernel-module-hid-generic-3.14-r0.1.intel_quark
kernel-module-usbhid-3.14-r0.1.intel_quark
kernel-module-cryptoloop-3.14-r0.1.intel_quark
kernel-module-spi-gpio-3.14-r0.1.intel_quark
kernel-module-qcserial-3.14-r0.1.intel_quark
kernel-module-igb-3.14-r0.1.intel_quark
kernel-module-f75111-3.14-r0.1.intel_quark
kernel-module-dw-dmac-3.14-r0.1.intel_quark
kernel-module-snd-3.14-r0.1.intel_quark
kernel-module-pca9685-3.14-r0.1.intel_quark
kernel-module-sc16is7xx-i2c-3.14-r0.1.intel_quark
kernel-module-m25p80-3.14-r0.1.intel_quark
kernel-module-mtd-blkdevs-3.14-r0.1.intel_quark
kernel-module-jffs2-3.14-r0.1.intel_quark
kernel-module-cfg80211-3.14-r0.1.intel_quark
kernel-module-bluetooth-3.14-r0.1.intel_quark
kernel-module-pch-udc-3.14-r0.1.intel_quark
kernel-module-libcomposite-3.14-r0.1.intel_quark
kernel-module-sc16is7xx-spi-3.14-r0.1.intel_quark
kernel-module-can-raw-3.14-r0.1.intel_quark
kernel-module-can-bcm-3.14-r0.1.intel_quark
kernel-module-can-gw-3.14-r0.1.intel_quark
kernel-module-can-j1939-3.14-r0.1.intel_quark
kernel-module-lis331dlh-intel-qrk-3.14-r0.1.intel_quark
kernel-module-industrialio-triggered-buffer-3.14-r0.1.intel_quark
kernel-module-snd-mixer-oss-3.14-r0.1.intel_quark
kernel-module-snd-hwdep-3.14-r0.1.intel_quark
kernel-module-snd-seq-device-3.14-r0.1.intel_quark
kernel-module-snd-timer-3.14-r0.1.intel_quark
kernel-module-mtdblock-3.14-r0.1.intel_quark
kernel-module-iwlwifi-3.14-r0.1.intel_quark
kernel-module-mac80211-3.14-r0.1.intel_quark
kernel-module-btusb-3.14-r0.1.intel_quark
kernel-module-hci-vhci-3.14-r0.1.intel_quark
kernel-module-usb-f-ecm-3.14-r0.1.intel_quark
kernel-module-usb-f-acm-3.14-r0.1.intel_quark
kernel-module-g-serial-3.14-r0.1.intel_quark
kernel-module-usb-f-serial-3.14-r0.1.intel_quark
kernel-module-usb-f-rndis-3.14-r0.1.intel_quark
kernel-module-usb-f-obex-3.14-r0.1.intel_quark
kernel-module-usb-f-mass-storage-3.14-r0.1.intel_quark
kernel-module-usb-f-ecm-subset-3.14-r0.1.intel_quark
kernel-module-ad7298-3.14-r0.1.intel_quark
kernel-module-adc1x8s102-3.14-r0.1.intel_quark
kernel-module-snd-rawmidi-3.14-r0.1.intel_quark
kernel-module-snd-pcm-3.14-r0.1.intel_quark
kernel-module-snd-seq-3.14-r0.1.intel_quark
kernel-module-rt2x00lib-3.14-r0.1.intel_quark
kernel-module-iwldvm-3.14-r0.1.intel_quark
kernel-module-iwlmvm-3.14-r0.1.intel_quark
kernel-module-g-ether-3.14-r0.1.intel_quark
kernel-module-g-mass-storage-3.14-r0.1.intel_quark
kernel-module-g-acm-ms-3.14-r0.1.intel_quark
kernel-module-snd-usbmidi-lib-3.14-r0.1.intel_quark
kernel-module-snd-ens1370-3.14-r0.1.intel_quark
kernel-module-snd-pcm-oss-3.14-r0.1.intel_quark
kernel-module-snd-ac97-codec-3.14-r0.1.intel_quark
kernel-module-snd-seq-midi-event-3.14-r0.1.intel_quark
kernel-module-rt2x00usb-3.14-r0.1.intel_quark
kernel-module-snd-usb-audio-3.14-r0.1.intel_quark
kernel-module-snd-intel8x0-3.14-r0.1.intel_quark
kernel-module-snd-seq-midi-3.14-r0.1.intel_quark
kernel-module-snd-seq-oss-3.14-r0.1.intel_quark
kernel-module-rt73usb-3.14-r0.1.intel_quark
kernel-modules-3.14-r0.1.intel_quark
```

After the upgrade the kernel modules are checked again:
```
root@WR-LX-6D80:/var/lib/iot# rpm -qa | grep kernel-module-
kernel-module-can-dev-3.14-r0.1.intel_quark
kernel-module-6lowpan-iphc-3.14-r1.1.intel_quark
kernel-module-ac97-bus-3.14-r1.1.intel_quark
kernel-module-ad7298-3.14-r1.1.intel_quark
kernel-module-adc1x8s102-3.14-r1.1.intel_quark
kernel-module-bluetooth-3.14-r1.1.intel_quark
kernel-module-btusb-3.14-r1.1.intel_quark
kernel-module-button-3.14-r1.1.intel_quark
kernel-module-can-3.14-r1.1.intel_quark
kernel-module-can-bcm-3.14-r1.1.intel_quark
kernel-module-can-gw-3.14-r1.1.intel_quark
kernel-module-can-j1939-3.14-r1.1.intel_quark
kernel-module-can-raw-3.14-r1.1.intel_quark
kernel-module-cdc-acm-3.14-r1.1.intel_quark
kernel-module-cfg80211-3.14-r1.1.intel_quark
kernel-module-chipreg-3.14-r1.1.intel_quark
kernel-module-cn-3.14-r1.1.intel_quark
kernel-module-cpuid-3.14-r1.1.intel_quark
kernel-module-crc-itu-t-3.14-r1.1.intel_quark
kernel-module-cryptoloop-3.14-r1.1.intel_quark
kernel-module-cy8c9540a-3.14-r1.1.intel_quark
kernel-module-dac7564-3.14-r1.1.intel_quark
kernel-module-dw-dmac-3.14-r1.1.intel_quark
kernel-module-dw-dmac-core-3.14-r1.1.intel_quark
kernel-module-efi-capsule-update-3.14-r1.1.intel_quark
kernel-module-evdev-3.14-r1.1.intel_quark
kernel-module-f75111-3.14-r1.1.intel_quark
kernel-module-g-acm-ms-3.14-r1.1.intel_quark
kernel-module-g-ether-3.14-r1.1.intel_quark
kernel-module-g-mass-storage-3.14-r1.1.intel_quark
kernel-module-g-serial-3.14-r1.1.intel_quark
kernel-module-gpio-pca953x-3.14-r1.1.intel_quark
kernel-module-gpio-sch-3.14-r1.1.intel_quark
kernel-module-hci-vhci-3.14-r1.1.intel_quark
kernel-module-hid-3.14-r1.1.intel_quark
kernel-module-hid-generic-3.14-r1.1.intel_quark
kernel-module-i2c-algo-bit-3.14-r1.1.intel_quark
kernel-module-igb-3.14-r1.1.intel_quark
kernel-module-iio-trig-hrtimer-3.14-r1.1.intel_quark
kernel-module-iio-trig-sysfs-3.14-r1.1.intel_quark
kernel-module-industrialio-3.14-r1.1.intel_quark
kernel-module-industrialio-triggered-buffer-3.14-r1.1.intel_quark
kernel-module-intel-qrk-audio-ctrl-3.14-r1.1.intel_quark
kernel-module-intel-qrk-gip-3.14-r1.1.intel_quark
kernel-module-intel-qrk-gip-test-3.14-r1.1.intel_quark
kernel-module-intel-qrk-thermal-3.14-r1.1.intel_quark
kernel-module-iwldvm-3.14-r1.1.intel_quark
kernel-module-iwlmvm-3.14-r1.1.intel_quark
kernel-module-iwlwifi-3.14-r1.1.intel_quark
kernel-module-jffs2-3.14-r1.1.intel_quark
kernel-module-kfifo-buf-3.14-r1.1.intel_quark
kernel-module-led-class-3.14-r1.1.intel_quark
kernel-module-libcomposite-3.14-r1.1.intel_quark
kernel-module-lis331dlh-intel-qrk-3.14-r1.1.intel_quark
kernel-module-loop-3.14-r1.1.intel_quark
kernel-module-m25p80-3.14-r1.1.intel_quark
kernel-module-mac80211-3.14-r1.1.intel_quark
kernel-module-minix-3.14-r1.1.intel_quark
kernel-module-mousedev-3.14-r1.1.intel_quark
kernel-module-msr-3.14-r1.1.intel_quark
kernel-module-mtd-3.14-r1.1.intel_quark
kernel-module-mtd-blkdevs-3.14-r1.1.intel_quark
kernel-module-mtdblock-3.14-r1.1.intel_quark
kernel-module-pca9685-3.14-r1.1.intel_quark
kernel-module-pch-gpio-vbus-3.14-r1.1.intel_quark
kernel-module-pch-udc-3.14-r1.1.intel_quark
kernel-module-processor-3.14-r1.1.intel_quark
kernel-module-qcserial-3.14-r1.1.intel_quark
kernel-module-regmap-i2c-3.14-r1.1.intel_quark
kernel-module-regmap-spi-3.14-r1.1.intel_quark
kernel-module-reiserfs-3.14-r1.1.intel_quark
kernel-module-rfkill-3.14-r1.1.intel_quark
kernel-module-rt2x00lib-3.14-r1.1.intel_quark
kernel-module-rt2x00usb-3.14-r1.1.intel_quark
kernel-module-rt73usb-3.14-r1.1.intel_quark
kernel-module-sc16is7xx-3.14-r1.1.intel_quark
kernel-module-sc16is7xx-i2c-3.14-r1.1.intel_quark
kernel-module-sc16is7xx-spi-3.14-r1.1.intel_quark
kernel-module-sha512-generic-3.14-r1.1.intel_quark
kernel-module-slcan-3.14-r1.1.intel_quark
kernel-module-snd-3.14-r1.1.intel_quark
kernel-module-snd-ac97-codec-3.14-r1.1.intel_quark
kernel-module-snd-ens1370-3.14-r1.1.intel_quark
kernel-module-snd-hwdep-3.14-r1.1.intel_quark
kernel-module-snd-intel8x0-3.14-r1.1.intel_quark
kernel-module-snd-mixer-oss-3.14-r1.1.intel_quark
kernel-module-snd-pcm-3.14-r1.1.intel_quark
kernel-module-snd-pcm-oss-3.14-r1.1.intel_quark
kernel-module-snd-rawmidi-3.14-r1.1.intel_quark
kernel-module-snd-seq-3.14-r1.1.intel_quark
kernel-module-snd-seq-device-3.14-r1.1.intel_quark
kernel-module-snd-seq-midi-3.14-r1.1.intel_quark
kernel-module-snd-seq-midi-event-3.14-r1.1.intel_quark
kernel-module-snd-seq-oss-3.14-r1.1.intel_quark
kernel-module-snd-timer-3.14-r1.1.intel_quark
kernel-module-snd-usb-audio-3.14-r1.1.intel_quark
kernel-module-snd-usbmidi-lib-3.14-r1.1.intel_quark
kernel-module-soundcore-3.14-r1.1.intel_quark
kernel-module-spi-bitbang-3.14-r1.1.intel_quark
kernel-module-spi-gpio-3.14-r1.1.intel_quark
kernel-module-spi-pxa2xx-pci-3.14-r1.1.intel_quark
kernel-module-spi-pxa2xx-platform-3.14-r1.1.intel_quark
kernel-module-st-sensors-3.14-r1.1.intel_quark
kernel-module-st-sensors-i2c-3.14-r1.1.intel_quark
kernel-module-st-sensors-spi-3.14-r1.1.intel_quark
kernel-module-tcrypt-3.14-r1.1.intel_quark
kernel-module-thermal-3.14-r1.1.intel_quark
kernel-module-u-ether-3.14-r1.1.intel_quark
kernel-module-u-serial-3.14-r1.1.intel_quark
kernel-module-udc-core-3.14-r1.1.intel_quark
kernel-module-usb-f-acm-3.14-r1.1.intel_quark
kernel-module-usb-f-ecm-3.14-r1.1.intel_quark
kernel-module-usb-f-ecm-subset-3.14-r1.1.intel_quark
kernel-module-usb-f-mass-storage-3.14-r1.1.intel_quark
kernel-module-usb-f-obex-3.14-r1.1.intel_quark
kernel-module-usb-f-rndis-3.14-r1.1.intel_quark
kernel-module-usb-f-serial-3.14-r1.1.intel_quark
kernel-module-usb-wwan-3.14-r1.1.intel_quark
kernel-module-usbhid-3.14-r1.1.intel_quark
kernel-module-vcan-3.14-r1.1.intel_quark
```

















