#!/bin/sh

BASE_DIR=/var/lib/iot/update
RPM_LOCKS=/var/lib/rpm/__db.*
RPM_PACKAGE=$1
LOG_FILE=$BASE_DIR/update_kernel_r1.log

echo "Kernel update r1 pre-install..." >> $LOG_FILE
date >> $LOG_FILE

# unwind the tarball containing the rpm files
echo "Unwinding $RPM_PACKAGE" >> $LOG_FILE
tar xzvf $RPM_PACKAGE >> $LOG_FILE

# check if there is any rpm locks
if [ 0 -ne 'ls $RPM_LOCKS' ]
then
	echo "Deleting rpm locks..." >> $LOG_FILE
        sudo rm -f $RPM_LOCKS
fi

echo "Pre-install succeeded. Exiting..." >> $LOG_FILE
exit 0
