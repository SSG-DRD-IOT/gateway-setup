#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_kernel_r1.log
MOUNT_POINT=/mnt/vfat

echo "Kernel update r1 install..." >> $LOG_FILE
date >> $LOG_FILE

# install the rpm
echo "Installing rpm files..." >> $LOG_FILE
for rpm_file in *.rpm
do
	echo "Installing $rpm_file..." >> $LOG_FILE
	sudo rpm -Uvh --nodeps $rpm_file >> $LOG_FILE
	if [ 0 -ne $? ]
	then
		echo "Failed to install $rpm_file. Exitting..." >> $LOG_FILE
		exit $?
	fi
done

# Creating mount point
echo "Creating mount point ($MOUNT_POINT)..." >> $LOG_FILE
sudo mkdir -p $MOUNT_POINT >> $LOG_FILE

# Determine the device containing the VFAT partition
echo "Determining mount partition..." >> $LOG_FILE
MOUNT_PART=$(sudo /usr/sbin/lvs --noheadings --nosuffix -o devices | sed -n "s/^ *//; s/ *$//; s/(.*)//; 1p" | sed -e "s/2$/1/")
MOUNT_PART=${MOUNT_PART%1}
echo "Mount partition is $MOUNT_PART" >> $LOG_FILE

# make sure vfat partition is not mounted
echo "Unmounting mount partition ($MOUNT_PART) in case it is already mounted..." >> $LOG_FILE
sudo /bin/umount -f $MOUNT_PART >> $LOG_FILE

# make sure mount point is not mounted
echo "Unmounting mount point ($MOUNT_POINT) in case it is already mounted..." >> $LOG_FILE
sudo /bin/umount -f $MOUNT_POINT >> $LOG_FILE

# mount the vfat partition
echo "Mounting mount partition ($MOUNT_PART) to mount point ($MOUNT_POINT)" >> $LOG_FILE
sudo /bin/mount $MOUNT_PART $MOUNT_POINT >> $LOG_FILE

# umount vfat partition
echo "Syncing and unmounting mount point ($MOUNT_POINT)"  >> $LOG_FILE
sync && sudo /bin/umount -f $MOUNT_POINT >> $LOG_FILE

echo "Install succeded. Exitting..." >> $LOG_FILE
exit 0
