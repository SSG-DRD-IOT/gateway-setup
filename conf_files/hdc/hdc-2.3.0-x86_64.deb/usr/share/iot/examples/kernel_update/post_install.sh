#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_kernel_r1.log
UPLOAD_DIR=/var/lib/iot/upload/

if [ -e "$LOG_FILE" ]
then
	echo "Kernel update r1 post-install..." >> $LOG_FILE
	date >> $LOG_FILE
	echo "Moving $LOG_FILE to $UPLOAD_DIR">> $LOG_FILE
	mv "$LOG_FILE" "$UPLOAD_DIR" >> $LOG_FILE
	echo "Post-install succeeded. Exiting..."
	exit 0
else
	exit 1
fi
