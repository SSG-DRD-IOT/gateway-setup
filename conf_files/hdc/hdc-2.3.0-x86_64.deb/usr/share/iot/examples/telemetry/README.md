Telemetry example
=================

This is an example application for using the API for telemetry. This example
demonstrates the following API calls:

- iot_telemetry_allocate
- iot_telemetry_deregister
- iot_telemetry_register
- iot_telemetry_publish
- iot_telemetry_free

