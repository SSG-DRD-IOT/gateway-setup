Location example
===============

This is an example application for using the API for location. This example
demonstrates the following API calls:

- iot_location_accuracy_set
- iot_location_allocate
- iot_location_altitude_accuracy_set
- iot_location_altitude_set
- iot_location_free
- iot_location_heading_set
- iot_location_source_set
- iot_location_speed_set
- iot_location_set
- iot_location_tag_set

