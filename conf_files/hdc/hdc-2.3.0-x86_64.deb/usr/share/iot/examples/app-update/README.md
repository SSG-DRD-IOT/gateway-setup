Application Update Example
=====================

Last revision
--------------
Thursday, October 27th, 2016

Description
-------------
This document explains the example provided to update an application, iot-app-complete to add a new action called "foo" and what is done in each step.

Before one can start doing an upgrade, all the files to be upgraded have to be produced first. They can be rpm packages, binary files, or any other files. In this example only rpm packages will be used. The process of producing upgrade packages/files is beyond the scope of this document.

ota_manifest.spec
----------------------
This is the manifest file that contains the high level information about the update, the platform to update and the update package itself. A few things to note:

- "archive_format" has to be specified to match the compression type used to compress the update package and for this context, as kernel update is only supported for linux platforms, only ".tar.gz" is supported.
- "sha256" has to match the sha256sum of the update package, otherwise it is going to fail.
- The format of this file has to be preserved in order to be uploaded to ePO


```
{
	"manifest": {
		"identifier": "Wind River Software Update Manifest",
		"operation": "app-install",
		"release" : {
			"version" : "new_app",
			"type" : "licensed"
		},
		"platforms": [{
			"product": "cpe:2.3:o:WindRiver:wrlinux:7.0.0.19:rcpl0019:*:en-US:*:hdc:intel-quark:*",
			"mfr_vendor_id" : "WindRiver",
			"mfr_device_id" : "IOT"
		}],
		"channelMode": "append",
			"channels" : [{
			"alias": "iot_ota",
			"name": "WR OTA",
			"type": "epo",
			"archive_format":"tar.gz",
			"url": "system-update.tar.gz",
			"sha256": "c37e38658859c1e0129c70ef46272a88cc6b5b1cc50cbe440a47ae795b381442",
			"language": "0000"
		}],
		"packages": [{ "name": "system-update.rpm" } ],
		"rebootOnCompletion": "no"
	}
}
```

update.json
-------------
This file contains more detailed information about the update and what to be done in all phases of the update. There are 4 phases:

- pre_install
- install
- post_install
- error action

Error-action is only triggered if any of the first 3 phases failed. These phases can be single line commands or scripts; and the scripts can be of any kind as long as the device support it. It is user's responsibility to make sure that the command/script provided will be able to execute. In this example we don't care about executable permissions, since we call `sh <script_name>`

```
{
    "name":"iot-app-complete update",
    "version":"2.0.0",
    "description":"Updating iot-app-complete",
    "pre_install":"sh pre_install.sh iot-app-complete",
    "install":"sh install.sh iot-app-complete",
    "post_install":"sh post_install.sh iot-app-complete",
    "error_action":"sh err_install.sh iot-app-complete",
    "reboot":"no",
    "compatibility": {
            "os_version":  "cpe:2.3:o:WindRiver:wrlinux:7.0.0.15:rcpl0015:*:en-US:*:hdc:intel-quark:*",
            "mfg_device_id":  "device_regex",
            "mfg_vendor_id": "mfg_regex",
            "model_name":    "model_regex",
            "serial": "serial_num_regex"
    },
    "extra_key_value_ary": [ { "key":"value" }],
    "custom_obj": { }
}
```

pre_install.sh
-----------------
This is the phase in which all the preparations before an install are done. In this example the update package only consists of a single binary file called iot-app-complete. Here it checks if there is a previous version of this application, and if there is, it is saved with a different name in the case the update fails, the working application will be put back in place.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME update pre-install..." >> $LOG_FILE
date >> $LOG_FILE

# finding the path of the application
APP_PATH=$(which $1)

# make a copy of the current application
if ! [ -z $APP_PATH ]
then
        echo "Making a copy of the current $APP_NAME" >> $LOG_FILE
        sudo cp $APP_PATH $BASE_DIR/$APP_NAME.old >> $LOG_FILE
fi

echo "Pre-install succeeded. Exiting..." >> $LOG_FILE
exit 0
```

install.sh
-----------
This is where the installation happens. Here we only copy a single file to the right location, overwriting an existing one. The application is also started; if it fails to start, that means something went wrong with the application update and err_install.sh will get called and restore the application if the previous version of the application is available.

One important thing to note here. If the application is started manually, which is the case in this example, the stdout and stderr have to be piped to a file or /dev/NULL. Otherwise the install.sh will hold them and it wont exit. This will cause the update process to hang, or fail.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME update install..." >> $LOG_FILE
date >> $LOG_FILE

# check the path of the application
# if there is no previous version of the application,
# put it in /usr/bin/
APP_PATH=$(which $APP_NAME)
if [ -z $APP_PATH ]
then
        APP_PATH=/usr/bin/$APP_NAME
fi

# copy the new app
echo "Copying the new $APP_NAME to $APP_PATH" >> $LOG_FILE
sudo cp $APP_NAME $APP_PATH >> $LOG_FILE

# start the application
echo "Starting the application..." >> $LOG_FILE
$APP_PATH > /tmp/$APP_NAME.log 2>&1 &
if [ 0 -eq $? ]
then
        echo "$APP_NAME was started successfully." >> $LOG_FILE
else
        echo "ERROR: $APP_NAME failed to start. Exiting..." >> $LOG_FILE
        exit 1
fi

echo "Install succeeded. Exiting..." >> $LOG_FILE
exit 0
```

post_install.sh
-----------------
In this phase, users can do cleanup of all the artifacts produced during the update. In this example, the log file generated will be moved to the upload directory so that it can be retrieved easily by user. The backup application is also removed as it is not needed any longer.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
UPLOAD_DIR=/var/lib/iot/upload/
APP_NAME=$1

if [ -e "$LOG_FILE" ]
then
        echo "$APP_NAME update post-install..." >> $LOG_FILE
        date >> $LOG_FILE
        echo "Moving $LOG_FILE to $UPLOAD_DIR">> $LOG_FILE
        mv "$LOG_FILE" "$UPLOAD_DIR" >> $LOG_FILE
        rm $BASE_DIR/$APP_NAME.old
        echo "Post-install succeeded. Exiting..."
        exit 0
else
        exit 1
fi
```

err_install.sh
---------------
This is used if there is something wrong with the update and tries to recover the application. In this example it tries to find the backup file that was created in the pre-install phase and puts it back and start it. It cannot do anything if there is no backup application saved.

```
#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME error_install" >> $LOG_FILE
date >> $LOG_FILE

# check the path of the application
# if there is no previous version of the application,
# put it in /usr/bin/
APP_PATH=$(which $APP_NAME)
if [ -z $APP_PATH ]
then
        APP_PATH=/usr/bin/$APP_NAME
fi

# if there is a copy of the original app, put it back
if [ -e $BASE_DIR/$APP_NAME.old  ]
then
        echo "Putting back the original $APP_NAME" >> $LOG_FILE
        cp $BASE_DIR/$APP_NAME.old $APP_PATH >> $LOG_FILE

        echo "Starting $APP_NAME..." >> $LOG_FILE
        $APP_PATH > /tmp/$APP_NAME.log 2>&1 &
else
        echo "$APP_NAME update failed. Too bad!!" >> $LOG_FILE
fi
```

iot-app-complete
-----------------------
A single binary file to update.

Log file
----------
There are 2 log files produced from this example, one from iot itself and another one created by all the install scripts provided.

iot_install_updates.log:
```
EPO manifest context ok, {"identifier":"Wind River Software Update Manifest","operation":"app-install","release":{"version":"new_app","type":"licensed"},"platforms":[{"product":"cpe:2.3:o:WindRiver:wrlinux:7.0.0.19:rcpl0019:*:en-US:*:hdc:intel-quark:*","mfr_vendor_id":"WindRiver","mfr_device_id":"IOT"}],"channelMode":"append","channels":[{"alias":"iot_ota","name":"WR OTA","type":"epo","url":"http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_new_app/app-install/0000/system-update.tar.gz","sha256":"41b72233c74d83334a03350aeb4046aad940f5b698d230f03be5c6abf7e55cc5","language":"0000"}],"packages":[{"name":"system-update.rpm"}],"rebootOnCompletion":"no"} 
Identifier               : Wind River Software Update Manifest

Operation                : app-install

Release->version         : new_app

Release->type            : licensed

Platforms->product       : cpe:2.3:o:WindRiver:wrlinux:7.0.0.19:rcpl0019:*:en-US:*:hdc:intel-quark:*

Platforms->mfr_vendor_id : WindRiver

Platforms->mfr_device_id : IOT

Channel Mode             : append

Channels->alias          : iot_ota

Channels->name           : WR OTA

Channels->type           : epo

Channels->url            : http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_new_app/app-install/0000/system-update.tar.gz

Channels->sha256         : 41b72233c74d83334a03350aeb4046aad940f5b698d230f03be5c6abf7e55cc5

Channels->language       : 0000

Packages                 : 

	system-update.rpm

RebootOnCompletion       : no

INFO: Start sending telemerty for logging ...
Iot Connected 
Executing command 'which sadmin'
Failed to execute the command:  which: no sadmin in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)

Command error:
which: no sadmin in (/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin)

INFO: MEC tools not found.
INFO: MEC tools do not exist.  No MEC operations will be run.

================================================
2016-10-26 17:11:40.433002:
Fetching the Update Package ... Start!
================================================

INFO: downloading pkg from uri: http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_new_app/app-install/0000/system-update.tar.gz
pkg_uri = http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_new_app/app-install/0000/system-update.tar.gz
Downloading http://podx.ahexternal.stgsmrrc1.novanp.adsdcsp.com/Software/Current/E667555A-A2FB-4FE2-8524-1F43DAA28D19_IOT_new_app/app-install/0000/system-update.tar.gz to local file /var/lib/iot/update/download/update_pkg.tar.gz

================================================
2016-10-26 17:11:41.506543:
Fetching the Update Package ... Successful!
 
================================================

Start sha checksum ...
INFO: Validating checksum on file /var/lib/iot/update/download/update_pkg.tar.gz

INFO: expected 41b72233c74d83334a03350aeb4046aad940f5b698d230f03be5c6abf7e55cc5

INFO: calculated 41b72233c74d83334a03350aeb4046aad940f5b698d230f03be5c6abf7e55cc5


================================================
2016-10-26 17:11:41.519681:
Fetching the Update Package ... Successful!
 
================================================

INFO: sha checksum OK

================================================
2016-10-26 17:11:41.529230:
Unarchiving the Update Package ... Start!
================================================


================================================
2016-10-26 17:11:41.766575:
Unarchiving the Update Package ... Successful!
================================================

Executing command 'sudo ls /var/lib/iot/update/download'
Command executed successfully: err_install.sh
install.sh
iot-app-complete
post_install.sh
pre_install.sh
update.json
update_pkg.tar.gz

 update manifest context ok: {u'pre_install': u'sh pre_install.sh', u'custom_obj': {}, u'extra_key_value_ary': [{u'key': u'value'}], u'name': u'iot-app-complete update', u'reboot': u'no', u'version': u'2.0.0', u'install': u'sh install.sh', u'error_action': u'sh err_install.sh', u'compatibility': {u'os_version': u'cpe:2.3:o:WindRiver:wrlinux:7.0.0.15:rcpl0015:*:en-US:*:hdc:intel-quark:*', u'mfg_device_id': u'device_regex', u'mfg_vendor_id': u'mfg_regex', u'serial': u'serial_num_regex', u'model_name': u'model_regex'}, u'post_install': u'sh post_install.sh', u'description': u'Updating iot-app-complete'}

==============================================
Software Update Package

name                         : iot-app-complete update

version                      : 2.0.0

description                  : Updating iot-app-complete

pre_install                  : sh pre_install.sh

install                      : sh install.sh

post_install                 : sh post_install.sh

error_action                 : sh err_install.sh

reboot                       : no

compatibility                :

   os_version       : cpe:2.3:o:WindRiver:wrlinux:7.0.0.15:rcpl0015:*:en-US:*:hdc:intel-quark:*

   mfg_device_id       : device_regex

   mfg_vendor_id       : mfg_regex

   serial       : serial_num_regex

   model_name       : model_regex

extra_key_value_ary          :

   {u'key': u'value'} 

custom_obj                   :

================================================

================================================
2016-10-26 17:11:41.962608:
Determing Device Compatibility
================================================


================================================
2016-10-26 17:11:41.967544:
Executing pre-install ... start !
================================================

Executing command 'sh pre_install.sh'
Command executed successfully: 

================================================
2016-10-26 17:11:42.159342:
Executing pre-install ... Successful !
================================================


================================================
2016-10-26 17:11:42.164620:
Executing install ... start !
================================================

Executing command 'sh install.sh'
Command executed successfully: 

================================================
2016-10-26 17:11:42.338692:
Executing install ... Successful !
================================================


================================================
2016-10-26 17:11:42.345751:
Executing post_install ... start !
================================================

Executing command 'sh post_install.sh'
Command executed successfully: Post-install succeded. Exitting...


================================================
2016-10-26 17:11:42.533142:
Executing post_install ... Successful !
================================================

INFO: MEC security in original state

Executing command 'sudo cp /var/lib/iot/update/iot_install_updates.log /var/lib/iot/upload'
```

update_app.log:
```
iot-app-complete update pre-install...
Wed Oct 26 17:11:42 UTC 2016
Making a copy of the current iot-app-complete
Pre-install succedded. Exitting...
iot-app-complete update install...
Wed Oct 26 17:11:42 UTC 2016
Copying the new iot-app-complete to /usr/bin/iot-app-complete
Starting the application...
iot-app-complete was started successfully.
Install succeded. Exitting...
iot-app-complete update post-install...
Wed Oct 26 17:11:42 UTC 2016
Moving /var/lib/iot/update/update_app.log to /var/lib/iot/upload/
```

Result
--------
Upon completion of the update, it was observed that a new action called "foo" is added to the application. Hence the update was successful
