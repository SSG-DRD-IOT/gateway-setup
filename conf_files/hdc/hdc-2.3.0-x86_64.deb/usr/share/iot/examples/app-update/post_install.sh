#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
UPLOAD_DIR=/var/lib/iot/upload/
APP_NAME=$1

if [ -e "$LOG_FILE" ]
then
	echo "$APP_NAME update post-install..." >> $LOG_FILE
	date >> $LOG_FILE
	echo "Moving $LOG_FILE to $UPLOAD_DIR">> $LOG_FILE
	mv "$LOG_FILE" "$UPLOAD_DIR" >> $LOG_FILE
	sudo rm -f $BASE_DIR/$APP_NAME.old
	echo "Post-install succeeded. Exiting..."
	exit 0
else
	exit 1
fi
