#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME update pre-install..." >> $LOG_FILE
date >> $LOG_FILE

# finding the path of the application
APP_PATH=$(which $1)

# make a copy of the current application
if ! [ -z $APP_PATH ]
then
	echo "Making a copy of the current $APP_NAME" >> $LOG_FILE
	sudo cp $APP_PATH $BASE_DIR/$APP_NAME.old >> $LOG_FILE
fi

echo "Pre-install succeeded. Exiting..." >> $LOG_FILE
exit 0
