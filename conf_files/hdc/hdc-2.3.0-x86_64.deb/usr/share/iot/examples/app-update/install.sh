#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME update install..." >> $LOG_FILE
date >> $LOG_FILE

# check the path of the application
# if there is no previous version of the application,
# put it in /usr/bin/
APP_PATH=$(which $APP_NAME)
if [ -z $APP_PATH ]
then
	APP_PATH=/usr/bin/$APP_NAME
fi

# copy the new app
echo "Copying the new $APP_NAME to $APP_PATH" >> $LOG_FILE
sudo cp $APP_NAME $APP_PATH >> $LOG_FILE

# start the application but schedule it with at so that it is not tied to this
# process.
echo "Starting the application..." >> $LOG_FILE
echo "/usr/bin/$APP_NAME > /dev/null 2>&1 &" |at now

echo "Install succeeded. Exiting..." >> $LOG_FILE
exit 0
