#!/bin/sh

BASE_DIR=/var/lib/iot/update
LOG_FILE=$BASE_DIR/update_app.log
APP_NAME=$1

echo "$APP_NAME error_install" >> $LOG_FILE
date >> $LOG_FILE

# check the path of the application
# if there is no previous version of the application,
# put it in /usr/bin/
APP_PATH=$(which $APP_NAME)
if [ -z $APP_PATH ]
then
        APP_PATH=/usr/bin/$APP_NAME
fi

# if there is a copy of the original app, put it back
if [ -e $BASE_DIR/$APP_NAME.old  ]
then
	echo "Putting back the original $APP_NAME" >> $LOG_FILE
	cp $BASE_DIR/$APP_NAME.old $APP_PATH >> $LOG_FILE

	echo "Starting $APP_NAME..." >> $LOG_FILE
	$APP_PATH > /tmp/$APP_NAME.log 2>&1 &
else
	echo "$APP_NAME update failed. Too bad!!" >> $LOG_FILE
fi
