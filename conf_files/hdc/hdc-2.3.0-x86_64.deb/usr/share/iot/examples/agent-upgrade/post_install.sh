#!/bin/sh

echo "Post install, nothing to do"
exit 0
