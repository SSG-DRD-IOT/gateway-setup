#!/bin/sh
DIR=`pwd`
SMART_LOG=$DIR/smart_update.log
SMART_DONE=0
SMART_SCRIPT=$DIR/smart_script.sh
SMART_JOB_LOG=$DIR/smart_job.log
INSTALL_LOG_DIR=/var/lib/iot/upload
INSTALL_LOG=$INSTALL_LOG_DIR/install_script_execute.log
PKG_NAME=$1

date > $INSTALL_LOG
echo "Start executing install script..." >>$INSTALL_LOG
# ------------------------------------------
# function that waits for a job to complete
# ------------------------------------------
wait_for_complete(){
	job=`cat $SMART_JOB_LOG | grep job | sed 's/^job \(.[^ ]*\) at.*/\1/'`
	echo "Scheduled job ID: $job"
	while [ "$SMART_DONE" = "0" ]; do {
		running=`atq | sed "s/\$job\t.*/NOTDONE/"`
		if [ "$running" == "NOTDONE" ]; then
			date >> $INSTALL_LOG
			echo "Job $job still running" >> $INSTALL_LOG
		else
			SMART_DONE=1
		fi
		sleep 3
	} done
}

# -----------------------------------------
# Clean up generated files
# -----------------------------------------
sudo rm -f $SMART_LOG $SMART_SCRIPT $SMART_JOB_LOG

# -----------------------------------------
# Uncompress the update package
# -----------------------------------------
tar -xvf $1

# -----------------------------------------
# write command to file to call with at -f
# -----------------------------------------
echo "sudo rpm -Uvh --replacepkgs *.rpm >>$INSTALL_LOG; echo \"OVERALL_RESULT:\$?\" >& $SMART_LOG" > $SMART_SCRIPT

# ---------------------------------------------------------------------------------
# Schedule the update and log, when it is check the result.
# The script does not need to be executable.
# ---------------------------------------------------------------------------------
at -f $SMART_SCRIPT now >& $SMART_JOB_LOG
# -----------------------------------------
# wait for the marker file
# -----------------------------------------
wait_for_complete

# -----------------------------------------
# Check the result and return accordingly
# -----------------------------------------
echo "Checking overall result..." >> $INSTALL_LOG
result=`cat $SMART_LOG | grep "OVERALL_RESULT:"| sed "s/OVERALL_RESULT:\(.*\)/\1/"`
if [ "$result" != "0" ]; then
	echo "Error: the install action failed: $result" >> $INSTALL_LOG
fi

date >> $INSTALL_LOG
echo "exiting with result: $result" >> $INSTALL_LOG

exit $result
