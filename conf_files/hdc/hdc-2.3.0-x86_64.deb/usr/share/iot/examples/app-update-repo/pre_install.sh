#!/bin/sh

# need to make sure smart is in the sudoers list.  Add a fragment
# here.
exists=`sudo -l|grep smart|wc -l`
if [ "$exists" = "0" ]; then
	echo "Updating sudoers.d with /usr/bin/smart"
	sudo rm /tmp/smart
	echo "iot ALL=(ALL) NOPASSWD: /usr/bin/smart" > /tmp/smart
	cd /tmp
	chmod 440 smart
	sudo chown root:root smart
	sudo cp /tmp/smart /etc/sudoers.d
	echo "Listing permissions"
	sudo -l
else
	echo "/usr/bin/smart is defined in sudoers.d"
fi
exit 0
