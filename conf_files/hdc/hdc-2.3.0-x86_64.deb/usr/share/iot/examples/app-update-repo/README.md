Application Update Using Package Manager
========================================

Last revision
-------------
Thursday December 13th

Description
-----------
This example shows how to use a package manager (e.g. smart) to update a Windriver Linux OS.

 *Note: this example shows how to update the OS and HDC applications.
This update may fail if any of the tools used in the install scripts
are being updated.  We recommend that those tools be updated before
calling the smart upgrade action.  Or in the case of HDC applications,
no result will be returned once the agent is reset.  If there are
errors in the update, typically it is due to a mismatch in packages,
compile options used or missing packages. *

pre_install.sh
--------------
This is the phase in which all the preparations would be made before
install is called.  In this example, there is nothing to do.

 *Please see the pre_install.sh script for details*

install.sh
-----------
This example install.sh is designed to invoke the smart package
manager and do an upgrade.  In this example, the HDC services are
updated.  The HDC all updates are
installed.  There are many options for the smart package manager that
are beyond the scope of this document.  In this example, we add a repo
and upgrade to the latest versions on that repo.  This is a common
work flow on most Linux systems, cf: apt-get, dnf, yum etc.

*Please see the install.sh script for details*

err_install.sh
---------------
This script is defined as the "error_action" in the update.json file.
This script will be called if there is a non-zero result returned in
any of the install phases.  In this example, there is nothing to do.

*Please see the err_install.sh script for details*

Result
--------
Upon completion of the update, the cloud will receive a successful result.
