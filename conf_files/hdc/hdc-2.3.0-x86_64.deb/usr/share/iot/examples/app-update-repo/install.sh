# -------------------------------------------------------------------
# This is a simple example on how to use smart to upgrade a WRL
# distro.  Note: the OS being updated and the rpms that are put in the
# repo must be built with the same flags.  Otherwise, smart will throw
# dependency errors.  This work flow will work for kernel, HDC, and
# generic app updates IF there is a version bump.  See kernel and HDC
# notes below.
# -------------------------------------------------------------------

# enable tracing for debugging
set -x

# find out what the machine type is for this build, then this script
# can be used for all WRL machine types.
NAME=`grep MACHINE /etc/iot/build_info.txt |sed 's/MACHINE.*= "\(.*\)"/\1/'`
BASE_URL=http://lbreports.wrs.com/hdc2nightly_repos/wrl7/LB21_7.0_RCPL0022/${NAME}
DIR=`pwd`
RESULT=$DIR/smart_done
sudo rm -f $RESULT

# make sure the the cache is purged and channel is fresh, remove any
# existing of this name
sudo smart clean
sudo smart channel --remove $NAME -y

# add the channel
sudo smart channel --add  $NAME type=rpm-md baseurl=$BASE_URL -y 

# update the pkg list
sudo smart update

# --------------------------------------------------------------------
# IDP only: 
# smart will return an error if the rpm is not signed.  Override that
# for testing.  WARNING: signing should not be overriden in a deployed
# environment.
# --------------------------------------------------------------------
idp_check=`uname -a|grep IDP-XT|wc -l`
if [ "$idp_check" > "0" ]; then
	echo "Overriding rpm signing requirement" 
	sudo smart config --set rpm-check-signatures=false
fi

# upgrade all available pkgs
sudo smart upgrade -y
RET=$?

# --------- KERNEL UPDATE NOTES -----------------------------------
# if updating the kernel, here are some notes:
# When using smart upgrade to upgrade an rcpl there are two problems:
#	1. the rcpl number is in the pkg name for some pkgs
#	2. kernel modules all have the same name
#Result, smart will not find any kernel pkgs to update.

#To update with smart, it is best to just download them:
#$ mkdir forced_updates
#$ cd force_updates
#$ smart download kernel* os-release*
#$ rpm -Uvh --replacepkgs *.rpm

#For quark only, the bzImage must be in the vfat partition, so update
#it:
#$ mount /dev/sda1 /mnt
#$ cp /boot/bzImage /mnt

# ----------- RCPL UPDATE NOTES ------------------------------------
# /etc/os-release is part of os-release-1.0-r0.0.all.rpm.  This
# package version does not get updated from rcpl to rcpl.  So, it must
# be forced to update.  E.g.
# smart download os-release*
# rpm -Uvh --replacepkgs os-release*.rpm
# Then, if you cat /etc/os-release, the proper rcpl change will be
# displayed.

# ----------- HDC SERVICE UPDATE NOTES -----------------------------
# If updating the iot-services, it is a best practice to restart the
# services:
# sudo iot-control --restart

# ------------ ERROR TRACKING --------------------------------------
# there may be more error checking required, leaving that as an
# exercise for the reader
echo result:${RET} > $RESULT

# wait for the marker file
echo -n "Checking result:"
res=`cat $RESULT | sed 's/result://'`
exit $res
